export interface UserSettings {
  nicotineConcentration: number; // mg/mL
  bottleSize: number; // mL
  puffsPerML: number;
  quitDate?: string;
  setupComplete: boolean;
  deviceType?: string;
  deviceName?: string;
}

export interface PuffRecord {
  id: string;
  timestamp: string;
  calculatedNicotine: number;
}

export interface DailyStats {
  date: string;
  totalPuffs: number;
  totalNicotine: number;
  sessions: number;
  averageTimeBetweenPuffs: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  unlocked: boolean;
  unlockedAt?: string;
  icon: string;
}

export interface DeviceType {
  id: string;
  name: string;
  description: string;
  characteristics: string[];
  nicotineRange: string;
  puffRange: string;
  batteryLife: string;
  icon: string;
}