import { UserSettings, PuffRecord, Achievement } from '../types';

const STORAGE_KEYS = {
  USER_SETTINGS: 'vqt_user_settings',
  PUFF_RECORDS: 'vqt_puff_records',
  ACHIEVEMENTS: 'vqt_achievements',
};

export const defaultSettings: UserSettings = {
  nicotineConcentration: 6,
  bottleSize: 30,
  puffsPerML: 100,
  setupComplete: false,
};

export const saveUserSettings = (settings: UserSettings): void => {
  localStorage.setItem(STORAGE_KEYS.USER_SETTINGS, JSON.stringify(settings));
};

export const getUserSettings = (): UserSettings => {
  const stored = localStorage.getItem(STORAGE_KEYS.USER_SETTINGS);
  return stored ? JSON.parse(stored) : defaultSettings;
};

export const savePuffRecords = (records: PuffRecord[]): void => {
  localStorage.setItem(STORAGE_KEYS.PUFF_RECORDS, JSON.stringify(records));
};

export const getPuffRecords = (): PuffRecord[] => {
  const stored = localStorage.getItem(STORAGE_KEYS.PUFF_RECORDS);
  return stored ? JSON.parse(stored) : [];
};

export const addPuffRecord = (record: PuffRecord): void => {
  const records = getPuffRecords();
  records.push(record);
  savePuffRecords(records);
};

export const saveAchievements = (achievements: Achievement[]): void => {
  localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
};

export const getAchievements = (): Achievement[] => {
  const stored = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);
  return stored ? JSON.parse(stored) : [];
};

export const exportData = () => {
  const data = {
    settings: getUserSettings(),
    records: getPuffRecords(),
    achievements: getAchievements(),
    exportDate: new Date().toISOString(),
  };
  
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `vape-quit-tracker-export-${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};