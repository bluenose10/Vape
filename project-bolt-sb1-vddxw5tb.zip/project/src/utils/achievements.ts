import { Achievement, PuffRecord } from '../types';

export const defaultAchievements: Achievement[] = [
  {
    id: 'first-puff',
    title: 'First Step',
    description: 'Logged your first puff - awareness is the beginning of change',
    unlocked: false,
    icon: 'target',
  },
  {
    id: 'week-tracking',
    title: 'Week Warrior',
    description: 'Tracked puffs for 7 consecutive days',
    unlocked: false,
    icon: 'calendar',
  },
  {
    id: 'reduced-50',
    title: 'Half Way There',
    description: 'Reduced daily puffs by 50% from your average',
    unlocked: false,
    icon: 'trending-down',
  },
  {
    id: 'nicotine-free-day',
    title: 'Clean Day',
    description: 'Went a full day without any puffs',
    unlocked: false,
    icon: 'check-circle',
  },
  {
    id: 'low-session',
    title: 'Session Control',
    description: 'Had only 1 vaping session in a day',
    unlocked: false,
    icon: 'shield',
  },
];

export const checkAchievements = (records: PuffRecord[], currentAchievements: Achievement[]): Achievement[] => {
  const updatedAchievements = [...currentAchievements];
  const now = new Date().toISOString();

  // First puff achievement
  const firstPuffAchievement = updatedAchievements.find(a => a.id === 'first-puff');
  if (firstPuffAchievement && !firstPuffAchievement.unlocked && records.length >= 1) {
    firstPuffAchievement.unlocked = true;
    firstPuffAchievement.unlockedAt = now;
  }

  // Week tracking achievement
  const weekAchievement = updatedAchievements.find(a => a.id === 'week-tracking');
  if (weekAchievement && !weekAchievement.unlocked) {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const recentRecords = records.filter(r => new Date(r.timestamp) >= sevenDaysAgo);
    const uniqueDays = new Set(recentRecords.map(r => new Date(r.timestamp).toDateString()));
    if (uniqueDays.size >= 7) {
      weekAchievement.unlocked = true;
      weekAchievement.unlockedAt = now;
    }
  }

  return updatedAchievements;
};