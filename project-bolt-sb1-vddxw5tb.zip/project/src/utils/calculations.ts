import { PuffRecord, UserSettings, DailyStats } from '../types';

export const calculateNicotinePerPuff = (settings: UserSettings): number => {
  return settings.nicotineConcentration / settings.puffsPerML;
};

export const createPuffRecord = (settings: UserSettings): PuffRecord => {
  const nicotinePerPuff = calculateNicotinePerPuff(settings);
  return {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    calculatedNicotine: nicotinePerPuff,
  };
};

export const getDailyStats = (records: PuffRecord[], date: string): DailyStats => {
  const dayStart = new Date(date);
  dayStart.setHours(0, 0, 0, 0);
  const dayEnd = new Date(date);
  dayEnd.setHours(23, 59, 59, 999);

  const dayRecords = records.filter(record => {
    const recordDate = new Date(record.timestamp);
    return recordDate >= dayStart && recordDate <= dayEnd;
  });

  const totalPuffs = dayRecords.length;
  const totalNicotine = dayRecords.reduce((sum, record) => sum + record.calculatedNicotine, 0);
  
  // Calculate sessions (puffs within 5 minutes of each other)
  let sessions = 0;
  let lastPuffTime: Date | null = null;
  
  dayRecords.forEach(record => {
    const puffTime = new Date(record.timestamp);
    if (!lastPuffTime || (puffTime.getTime() - lastPuffTime.getTime()) > 5 * 60 * 1000) {
      sessions++;
    }
    lastPuffTime = puffTime;
  });

  // Calculate average time between puffs
  let averageTimeBetweenPuffs = 0;
  if (dayRecords.length > 1) {
    const times = dayRecords.map(r => new Date(r.timestamp).getTime()).sort();
    const intervals = [];
    for (let i = 1; i < times.length; i++) {
      intervals.push(times[i] - times[i - 1]);
    }
    averageTimeBetweenPuffs = intervals.reduce((sum, interval) => sum + interval, 0) / intervals.length / 60000; // in minutes
  }

  return {
    date,
    totalPuffs,
    totalNicotine: Math.round(totalNicotine * 100) / 100,
    sessions,
    averageTimeBetweenPuffs: Math.round(averageTimeBetweenPuffs),
  };
};

export const getTimelineData = (records: PuffRecord[], date: string) => {
  const dayStart = new Date(date);
  dayStart.setHours(0, 0, 0, 0);
  
  const timeline = Array.from({ length: 96 }, (_, index) => {
    const slotStart = new Date(dayStart);
    slotStart.setMinutes(index * 15);
    const slotEnd = new Date(slotStart);
    slotEnd.setMinutes(slotEnd.getMinutes() + 15);
    
    const puffsInSlot = records.filter(record => {
      const recordTime = new Date(record.timestamp);
      return recordTime >= slotStart && recordTime < slotEnd;
    });
    
    return {
      timeSlot: slotStart.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false 
      }),
      hour: slotStart.getHours(),
      minute: slotStart.getMinutes(),
      puffCount: puffsInSlot.length,
      totalNicotine: puffsInSlot.reduce((sum, record) => sum + record.calculatedNicotine, 0),
    };
  });
  
  return timeline;
};