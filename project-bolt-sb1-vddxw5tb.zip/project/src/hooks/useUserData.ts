import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface UserSettings {
  id: string;
  nicotine_concentration: number;
  bottle_size: number;
  puffs_per_ml: number;
  quit_date: string | null;
  setup_complete: boolean;
  device_type: string;
  device_name: string;
}

interface PuffRecord {
  id: string;
  timestamp: string;
  calculated_nicotine: number;
  session_id: string | null;
}

export const useUserData = (userId: string | undefined) => {
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [puffRecords, setPuffRecords] = useState<PuffRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      fetchUserData();
    }
  }, [userId]);

  const fetchUserData = async () => {
    if (!userId) return;

    try {
      setLoading(true);

      // Fetch user settings
      const { data: settingsData, error: settingsError } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (settingsError) {
        console.error('Settings error:', settingsError);
        throw settingsError;
      }
      
      console.log('Fetched settings:', settingsData);
      setSettings(settingsData);

      // Fetch puff records (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const { data: puffData, error: puffError } = await supabase
        .from('puff_records')
        .select('*')
        .eq('user_id', userId)
        .gte('timestamp', thirtyDaysAgo.toISOString())
        .order('timestamp', { ascending: false });

      if (puffError) {
        console.error('Puff records error:', puffError);
        throw puffError;
      }
      
      console.log('Fetched puff records:', puffData?.length || 0, 'records');
      setPuffRecords(puffData || []);

    } catch (error) {
      console.error('Error fetching user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (newSettings: Partial<UserSettings>) => {
    if (!userId || !settings) return;

    try {
      console.log('Updating settings:', newSettings);
      
      const { error } = await supabase
        .from('user_settings')
        .update(newSettings)
        .eq('user_id', userId);

      if (error) {
        console.error('Update settings error:', error);
        throw error;
      }

      console.log('Settings updated successfully');
      setSettings({ ...settings, ...newSettings });
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    }
  };

  const addPuffRecord = async (calculatedNicotine: number) => {
    if (!userId) {
      console.error('No user ID available for adding puff record');
      return;
    }

    try {
      console.log('Adding puff record for user:', userId, 'with nicotine:', calculatedNicotine);
      
      const { data, error } = await supabase
        .from('puff_records')
        .insert({
          user_id: userId,
          calculated_nicotine: calculatedNicotine,
          timestamp: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) {
        console.error('Add puff record error:', error);
        throw error;
      }

      console.log('Puff record added successfully:', data);
      setPuffRecords(prev => [data, ...prev]);
      return data;
    } catch (error) {
      console.error('Error adding puff record:', error);
      throw error;
    }
  };

  return {
    settings,
    puffRecords,
    loading,
    updateSettings,
    addPuffRecord,
    refetch: fetchUserData,
  };
};