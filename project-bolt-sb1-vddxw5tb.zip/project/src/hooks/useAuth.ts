import { useState, useEffect } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [firstName, setFirstName] = useState<string>('');

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        extractFirstName(session.user);
      }
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          extractFirstName(session.user);
        } else {
          setFirstName('');
        }
        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const extractFirstName = (user: User) => {
    // Try to get full_name from user_metadata
    const fullName = user.user_metadata?.full_name;
    if (fullName && typeof fullName === 'string') {
      // Extract first name by splitting on space and taking the first part
      const firstNameExtracted = fullName.split(' ')[0].trim();
      setFirstName(firstNameExtracted);
    } else {
      // Fallback to empty string if no full name available
      setFirstName('');
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return {
    user,
    firstName,
    loading,
    signOut,
  };
};