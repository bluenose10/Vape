import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          avatar_url?: string | null;
        };
        Update: {
          full_name?: string | null;
          avatar_url?: string | null;
        };
      };
      user_settings: {
        Row: {
          id: string;
          user_id: string;
          nicotine_concentration: number;
          bottle_size: number;
          puffs_per_ml: number;
          quit_date: string | null;
          setup_complete: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          nicotine_concentration?: number;
          bottle_size?: number;
          puffs_per_ml?: number;
          quit_date?: string | null;
          setup_complete?: boolean;
        };
        Update: {
          nicotine_concentration?: number;
          bottle_size?: number;
          puffs_per_ml?: number;
          quit_date?: string | null;
          setup_complete?: boolean;
        };
      };
      puff_records: {
        Row: {
          id: string;
          user_id: string;
          timestamp: string;
          calculated_nicotine: number;
          session_id: string | null;
          created_at: string;
        };
        Insert: {
          user_id: string;
          timestamp?: string;
          calculated_nicotine: number;
          session_id?: string | null;
        };
        Update: {
          calculated_nicotine?: number;
          session_id?: string | null;
        };
      };
      user_goals: {
        Row: {
          id: string;
          user_id: string;
          goal_type: 'daily_puffs' | 'nicotine_reduction' | 'quit_date' | 'session_limit';
          target_value: number | null;
          current_value: number;
          target_date: string | null;
          is_active: boolean;
          achieved_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          goal_type: 'daily_puffs' | 'nicotine_reduction' | 'quit_date' | 'session_limit';
          target_value?: number | null;
          current_value?: number;
          target_date?: string | null;
          is_active?: boolean;
        };
        Update: {
          target_value?: number | null;
          current_value?: number;
          target_date?: string | null;
          is_active?: boolean;
          achieved_at?: string | null;
        };
      };
      achievements: {
        Row: {
          id: string;
          title: string;
          description: string;
          icon: string;
          criteria_type: string;
          criteria_value: number | null;
          is_active: boolean;
          created_at: string;
        };
      };
      user_achievements: {
        Row: {
          id: string;
          user_id: string;
          achievement_id: string;
          unlocked_at: string;
          progress: number;
        };
        Insert: {
          user_id: string;
          achievement_id: string;
          progress?: number;
        };
      };
    };
  };
}