import React, { useState, useEffect } from 'react';
import { Settings, LogOut, Smartphone } from 'lucide-react';
import { HomePage } from './components/HomePage';
import { AuthModal } from './components/AuthModal';
import { SetupModal } from './components/SetupModal';
import { SettingsModal } from './components/SettingsModal';
import { GoalsModal } from './components/GoalsModal';
import { DeviceTypeModal } from './components/DeviceTypeModal';
import { ReportsModal } from './components/ReportsModal';
import { AIChatModal } from './components/AIChatModal';
import { BottomNavBar } from './components/BottomNavBar';
import { Dashboard } from './components/Dashboard';
import { Timeline } from './components/Timeline';
import { StatsPanel } from './components/StatsPanel';
import { PuffButton } from './components/PuffButton';
import { AchievementNotification } from './components/AchievementNotification';
import { PWAInstallModal } from './components/PWAInstallModal';
import { useAuth } from './hooks/useAuth';
import { useUserData } from './hooks/useUserData';
import { getDailyStats, getTimelineData, calculateNicotinePerPuff } from './utils/calculations';

function App() {
  const { user, firstName, loading: authLoading, signOut } = useAuth();
  const { settings, puffRecords, loading: dataLoading, updateSettings, addPuffRecord } = useUserData(user?.id);
  
  const [showAuth, setShowAuth] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showGoals, setShowGoals] = useState(false);
  const [showDeviceTypes, setShowDeviceTypes] = useState(false);
  const [showReports, setShowReports] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [showPWAModal, setShowPWAModal] = useState(false);
  const [newAchievement, setNewAchievement] = useState(null);
  const [currentView, setCurrentView] = useState<'dashboard' | 'tracker' | 'devices'>('dashboard');

  // PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);

  // PWA Install Prompt Event Listeners
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      // Prevent the mini-infobar from appearing on mobile
      e.preventDefault();
      // Stash the event so it can be triggered later
      setDeferredPrompt(e);
      // Show the install button
      setShowInstallPrompt(true);
    };

    const handleAppInstalled = () => {
      // Hide the install button after successful installation
      setShowInstallPrompt(false);
      setDeferredPrompt(null);
      console.log('PWA was installed');
    };

    // Listen for the beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    // Listen for the appinstalled event
    window.addEventListener('appinstalled', handleAppInstalled);

    // Check if app is already installed (standalone mode)
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setShowInstallPrompt(false);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    // Show the instructional modal first
    setShowPWAModal(true);
  };

  const handleActualInstall = async () => {
    if (!deferredPrompt) {
      // If no prompt available, close modal and let user follow manual instructions
      setShowPWAModal(false);
      return;
    }

    // Show the install prompt
    deferredPrompt.prompt();
    
    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      console.log('User accepted the install prompt');
    } else {
      console.log('User dismissed the install prompt');
    }
    
    // Clear the deferredPrompt variable
    setDeferredPrompt(null);
    setShowInstallPrompt(false);
    setShowPWAModal(false);
  };

  // Show setup modal if user is authenticated but setup is not complete
  React.useEffect(() => {
    if (user && settings && !settings.setup_complete) {
      setShowSetup(true);
    }
  }, [user, settings]);

  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  // Convert database records to app format
  const appPuffRecords = puffRecords.map(record => ({
    id: record.id,
    timestamp: record.timestamp,
    calculatedNicotine: record.calculated_nicotine,
  }));

  const todayStats = getDailyStats(appPuffRecords, today);
  const yesterdayStats = getDailyStats(appPuffRecords, yesterday);
  const timelineData = getTimelineData(appPuffRecords, today);

  const handlePuff = async () => {
    if (!settings) return;

    const nicotinePerPuff = calculateNicotinePerPuff({
      nicotineConcentration: settings.nicotine_concentration,
      bottleSize: settings.bottle_size,
      puffsPerML: settings.puffs_per_ml,
      setupComplete: settings.setup_complete,
    });

    try {
      console.log('Adding puff record with nicotine:', nicotinePerPuff);
      const result = await addPuffRecord(nicotinePerPuff);
      console.log('Puff record added successfully:', result);
    } catch (error) {
      console.error('Error logging puff:', error);
      alert('Failed to log puff. Please check your connection and try again.');
    }
  };

  const handleSaveSettings = async (newSettings: any) => {
    try {
      await updateSettings({
        nicotine_concentration: newSettings.nicotineConcentration,
        bottle_size: newSettings.bottleSize,
        puffs_per_ml: newSettings.puffsPerML,
        device_type: newSettings.deviceType || 'pod-system',
        device_name: newSettings.deviceName || '',
        setup_complete: true,
      });
      setShowSetup(false);
      setShowSettings(false);
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  const handleDeviceSelect = async (device: any) => {
    if (!settings) return;
    
    try {
      await updateSettings({
        device_type: device.id,
        device_name: device.name,
      });
      setShowDeviceTypes(false);
    } catch (error) {
      console.error('Error updating device type:', error);
    }
  };

  const trackingDays = puffRecords.length > 0 
    ? Math.ceil((Date.now() - new Date(puffRecords[0].timestamp).getTime()) / (1000 * 60 * 60 * 24))
    : 0;

  // Show loading screen
  if (authLoading || (user && dataLoading)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100 flex items-center justify-center px-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your data...</p>
        </div>
      </div>
    );
  }

  // Show homepage if not authenticated
  if (!user) {
    return (
      <>
        <HomePage onGetStarted={() => setShowAuth(true)} />
        
        <AuthModal
          isOpen={showAuth}
          onClose={() => setShowAuth(false)}
          onSuccess={() => setShowAuth(false)}
        />
      </>
    );
  }

  // Show setup modal if setup is not complete
  if (showSetup && settings) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100">
        <SetupModal 
          settings={{
            nicotineConcentration: settings.nicotine_concentration,
            bottleSize: settings.bottle_size,
            puffsPerML: settings.puffs_per_ml,
            setupComplete: settings.setup_complete,
            deviceType: settings.device_type,
            deviceName: settings.device_name,
          }}
          onSave={handleSaveSettings}
          onClose={() => setShowSetup(false)}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100 pb-20">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-3 sm:px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="min-w-0 flex-1">
              <h1 className="text-lg sm:text-xl font-bold text-gray-900 truncate">
                {firstName ? `Welcome back, ${firstName}!` : 'Vape Quit Tracker'}
              </h1>
              <p className="text-xs sm:text-sm text-gray-600 truncate">
                {trackingDays > 0 ? `Tracking for ${trackingDays} days` : 'Ready to start tracking'}
              </p>
            </div>
            <div className="flex gap-1 sm:gap-2 ml-2">
              <button
                onClick={() => setShowDeviceTypes(true)}
                className="p-2 hover:bg-green-100 rounded-full transition-colors touch-manipulation"
                title="Device Types"
              >
                <Smartphone size={18} className="text-green-600" />
              </button>
              <button
                onClick={() => setShowSettings(true)}
                className="p-2 hover:bg-green-100 rounded-full transition-colors touch-manipulation"
                title="Settings"
              >
                <Settings size={18} className="text-green-600" />
              </button>
              <button
                onClick={signOut}
                className="p-2 hover:bg-red-100 rounded-full transition-colors touch-manipulation"
                title="Sign Out"
              >
                <LogOut size={18} className="text-red-600" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-md mx-auto px-3 sm:px-4 py-2 sm:py-3">
        <div className="flex bg-white/70 backdrop-blur-sm rounded-xl p-1 shadow-sm">
          <button
            onClick={() => setCurrentView('dashboard')}
            className={`flex-1 py-2 sm:py-3 px-2 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-all touch-manipulation ${
              currentView === 'dashboard'
                ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setCurrentView('tracker')}
            className={`flex-1 py-2 sm:py-3 px-2 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-all touch-manipulation ${
              currentView === 'tracker'
                ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
            }`}
          >
            Quick Track
          </button>
          <button
            onClick={() => setCurrentView('devices')}
            className={`flex-1 py-2 sm:py-3 px-2 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-all touch-manipulation ${
              currentView === 'devices'
                ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
            }`}
          >
            Devices
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-3 sm:px-4 pb-6 sm:pb-8">
        {currentView === 'dashboard' && settings ? (
          <Dashboard 
            puffRecords={appPuffRecords} 
            settings={{
              nicotineConcentration: settings.nicotine_concentration,
              bottleSize: settings.bottle_size,
              puffsPerML: settings.puffs_per_ml,
              setupComplete: settings.setup_complete,
              deviceType: settings.device_type,
              deviceName: settings.device_name,
            }} 
          />
        ) : currentView === 'devices' ? (
          <div className="space-y-4 sm:space-y-6">
            {/* Current Device Info */}
            {settings && (
              <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4 flex items-center gap-2">
                  <Smartphone className="text-green-600" size={18} />
                  Current Device
                </h3>
                <div className="bg-gradient-to-r from-green-50 to-teal-50 rounded-xl p-3 sm:p-4 border border-green-100">
                  <div className="flex items-center justify-between mb-3">
                    <div className="min-w-0 flex-1">
                      <h4 className="font-semibold text-gray-900 text-sm sm:text-base truncate">
                        {settings.device_name || 'Pod System'}
                      </h4>
                      <p className="text-xs sm:text-sm text-gray-600 capitalize">
                        {settings.device_type?.replace('-', ' ') || 'pod system'}
                      </p>
                    </div>
                    <button
                      onClick={() => setShowDeviceTypes(true)}
                      className="bg-green-500 text-white px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium hover:bg-green-600 transition-colors touch-manipulation ml-2"
                    >
                      Change
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-3 sm:gap-4 text-xs sm:text-sm">
                    <div>
                      <span className="text-gray-500">Nicotine:</span>
                      <span className="font-medium ml-1 sm:ml-2">{settings.nicotine_concentration}mg/mL</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Puffs/mL:</span>
                      <span className="font-medium ml-1 sm:ml-2">{settings.puffs_per_ml}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Device Type Guide */}
            <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg">
              <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Device Types Guide</h3>
              <div className="space-y-2 sm:space-y-3">
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <span className="text-xl sm:text-2xl">🔋</span>
                  <div className="min-w-0 flex-1">
                    <h4 className="font-medium text-gray-900 text-sm sm:text-base">Disposables</h4>
                    <p className="text-xs sm:text-sm text-gray-600">Single-use, high nicotine (20-50mg)</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <span className="text-xl sm:text-2xl">📱</span>
                  <div className="min-w-0 flex-1">
                    <h4 className="font-medium text-gray-900 text-sm sm:text-base">Pod Systems</h4>
                    <p className="text-xs sm:text-sm text-gray-600">Refillable pods, moderate nicotine (3-50mg)</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <span className="text-xl sm:text-2xl">📦</span>
                  <div className="min-w-0 flex-1">
                    <h4 className="font-medium text-gray-900 text-sm sm:text-base">Box Mods</h4>
                    <p className="text-xs sm:text-sm text-gray-600">Advanced settings, low nicotine (0-12mg)</p>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setShowDeviceTypes(true)}
                className="w-full mt-4 bg-gradient-to-r from-green-500 to-teal-500 text-white py-3 px-4 rounded-xl font-medium hover:from-green-600 hover:to-teal-600 transition-all touch-manipulation"
              >
                View All Device Types
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4 sm:space-y-6">
            {/* Stats Panel */}
            <StatsPanel todayStats={todayStats} yesterdayStats={yesterdayStats} />

            {/* Puff Button */}
            <div className="flex justify-center py-6 sm:py-8">
              <PuffButton onPuff={handlePuff} />
            </div>

            {/* Quick Info */}
            {settings && (
              <div className="bg-white rounded-xl p-4 shadow-md">
                <div className="text-center space-y-2">
                  <p className="text-xs sm:text-sm text-gray-600">
                    Each puff contains ~<span className="font-semibold text-green-600">
                      {calculateNicotinePerPuff({
                        nicotineConcentration: settings.nicotine_concentration,
                        bottleSize: settings.bottle_size,
                        puffsPerML: settings.puffs_per_ml,
                        setupComplete: settings.setup_complete,
                      }).toFixed(2)}mg
                    </span> nicotine
                  </p>
                  <p className="text-xs text-gray-500">
                    Based on {settings.nicotine_concentration}mg/mL concentration
                  </p>
                </div>
              </div>
            )}

            {/* Timeline */}
            <Timeline data={timelineData} />
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <BottomNavBar
        onOpenAIChat={() => setShowAIChat(true)}
        onOpenReports={() => setShowReports(true)}
        onOpenGoals={() => setShowGoals(true)}
        showInstallPrompt={showInstallPrompt}
        onInstallClick={handleInstallClick}
      />

      {/* Modals */}
      {showSettings && settings && (
        <SettingsModal
          settings={{
            nicotineConcentration: settings.nicotine_concentration,
            bottleSize: settings.bottle_size,
            puffsPerML: settings.puffs_per_ml,
            setupComplete: settings.setup_complete,
            deviceType: settings.device_type,
            deviceName: settings.device_name,
          }}
          onSave={handleSaveSettings}
          onClose={() => setShowSettings(false)}
          onClearData={() => {
            // Handle clear data - would need to implement
            console.log('Clear data requested');
          }}
        />
      )}

      {showGoals && user && (
        <GoalsModal
          isOpen={showGoals}
          onClose={() => setShowGoals(false)}
          userId={user.id}
        />
      )}

      {showReports && user && (
        <ReportsModal
          isOpen={showReports}
          onClose={() => setShowReports(false)}
          userId={user.id}
        />
      )}

      {showAIChat && user && (
        <AIChatModal
          isOpen={showAIChat}
          onClose={() => setShowAIChat(false)}
          userId={user.id}
        />
      )}

      <DeviceTypeModal
        isOpen={showDeviceTypes}
        onClose={() => setShowDeviceTypes(false)}
        onSelect={handleDeviceSelect}
        currentDevice={settings?.device_name}
      />

      {/* PWA Install Modal */}
      <PWAInstallModal
        isOpen={showPWAModal}
        onClose={() => setShowPWAModal(false)}
        onInstall={handleActualInstall}
      />

      {/* Achievement Notification */}
      <AchievementNotification
        achievement={newAchievement}
        onClose={() => setNewAchievement(null)}
      />
    </div>
  );
}

export default App;