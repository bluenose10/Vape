import React, { useState } from 'react';
import { X, Save, Download, Trash2 } from 'lucide-react';
import { UserSettings } from '../types';
import { exportData } from '../utils/storage';
import { supabase } from '../lib/supabase';

interface SettingsModalProps {
  settings: UserSettings;
  onSave: (settings: UserSettings) => void;
  onClose: () => void;
  onClearData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ 
  settings, 
  onSave, 
  onClose, 
  onClearData 
}) => {
  const [formData, setFormData] = useState(settings);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  const handleClearData = async () => {
    setLoading(true);
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Delete all puff records for this user
      const { error } = await supabase
        .from('puff_records')
        .delete()
        .eq('user_id', user.id);

      if (error) throw error;

      alert('All puff data has been cleared successfully.');
      setShowClearConfirm(false);
      onClose();
      
      // Refresh the page to update the UI
      window.location.reload();
    } catch (error) {
      console.error('Error clearing data:', error);
      alert('Failed to clear data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleExportData = async () => {
    setLoading(true);
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Fetch all user data
      const [settingsResponse, puffRecordsResponse, goalsResponse] = await Promise.all([
        supabase.from('user_settings').select('*').eq('user_id', user.id).single(),
        supabase.from('puff_records').select('*').eq('user_id', user.id).order('timestamp', { ascending: false }),
        supabase.from('user_goals').select('*').eq('user_id', user.id)
      ]);

      const exportData = {
        user_profile: {
          id: user.id,
          email: user.email,
          created_at: user.created_at
        },
        settings: settingsResponse.data,
        puff_records: puffRecordsResponse.data || [],
        goals: goalsResponse.data || [],
        export_date: new Date().toISOString(),
        total_records: puffRecordsResponse.data?.length || 0
      };

      // Create and download file
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `vape-quit-tracker-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      alert(`Data exported successfully! ${exportData.total_records} puff records included.`);
    } catch (error) {
      console.error('Error exporting data:', error);
      alert('Failed to export data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl max-h-screen overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Settings</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nicotine Concentration (mg/mL)
            </label>
            <input
              type="number"
              value={formData.nicotineConcentration}
              onChange={(e) => setFormData({ ...formData, nicotineConcentration: Number(e.target.value) })}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              min="0"
              max="50"
              step="0.1"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Bottle Size (mL)
            </label>
            <input
              type="number"
              value={formData.bottleSize}
              onChange={(e) => setFormData({ ...formData, bottleSize: Number(e.target.value) })}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              min="1"
              max="100"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Estimated Puffs per mL
            </label>
            <input
              type="number"
              value={formData.puffsPerML}
              onChange={(e) => setFormData({ ...formData, puffsPerML: Number(e.target.value) })}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              min="50"
              max="200"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-teal-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-teal-600 transition-colors flex items-center justify-center gap-2"
          >
            <Save size={20} />
            Save Settings
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-gray-200 space-y-3">
          <h3 className="text-lg font-semibold text-gray-900">Data Management</h3>
          
          <button
            onClick={handleExportData}
            disabled={loading}
            className="w-full bg-blue-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-blue-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Download size={20} />
            {loading ? 'Exporting...' : 'Export Data'}
          </button>

          {!showClearConfirm ? (
            <button
              onClick={() => setShowClearConfirm(true)}
              className="w-full bg-red-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-red-600 transition-colors flex items-center justify-center gap-2"
            >
              <Trash2 size={20} />
              Clear All Data
            </button>
          ) : (
            <div className="space-y-2">
              <p className="text-sm text-gray-600 text-center">Are you sure? This cannot be undone.</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="py-2 px-4 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleClearData}
                  disabled={loading}
                  className="py-2 px-4 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Clearing...' : 'Clear Data'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};