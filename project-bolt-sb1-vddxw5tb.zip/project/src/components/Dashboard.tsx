import React from 'react';
import { Activity, Clock, Zap, TrendingDown, Calendar, Target } from 'lucide-react';
import { PuffRecord, UserSettings } from '../types';
import { getDailyStats, getTimelineData, calculateNicotinePerPuff } from '../utils/calculations';

interface DashboardProps {
  puffRecords: PuffRecord[];
  settings: UserSettings;
}

export const Dashboard: React.FC<DashboardProps> = ({ puffRecords, settings }) => {
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  
  const todayStats = getDailyStats(puffRecords, today);
  const yesterdayStats = getDailyStats(puffRecords, yesterday);
  const timelineData = getTimelineData(puffRecords, today);
  const nicotinePerPuff = calculateNicotinePerPuff(settings);

  // Calculate hourly breakdown for the last 24 hours
  const hourlyData = Array.from({ length: 24 }, (_, hour) => {
    const hourData = timelineData.filter(slot => slot.hour === hour);
    const totalPuffs = hourData.reduce((sum, slot) => sum + slot.puffCount, 0);
    const totalNicotine = hourData.reduce((sum, slot) => sum + slot.totalNicotine, 0);
    
    return {
      hour,
      puffs: totalPuffs,
      nicotine: totalNicotine,
      sessions: totalPuffs > 0 ? Math.ceil(totalPuffs / 3) : 0 // Rough session estimate
    };
  });

  const maxHourlyPuffs = Math.max(...hourlyData.map(h => h.puffs), 1);
  const peakHour = hourlyData.reduce((peak, current) => 
    current.puffs > peak.puffs ? current : peak, hourlyData[0]);

  const getBarHeight = (puffs: number) => {
    return Math.max((puffs / maxHourlyPuffs) * 100, 2);
  };

  const getBarColor = (puffs: number) => {
    if (puffs === 0) return 'bg-gray-200';
    const intensity = puffs / maxHourlyPuffs;
    if (intensity <= 0.25) return 'bg-green-400';
    if (intensity <= 0.5) return 'bg-yellow-400';
    if (intensity <= 0.75) return 'bg-orange-400';
    return 'bg-red-500';
  };

  const StatCard: React.FC<{
    title: string;
    value: string | number;
    subtitle?: string;
    icon: React.ReactNode;
    trend?: 'up' | 'down' | 'neutral';
    trendValue?: number;
    color?: string;
  }> = ({ title, value, subtitle, icon, trend, trendValue, color = 'teal' }) => (
    <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
      <div className="flex items-center justify-between mb-3 sm:mb-4">
        <div className={`p-2 sm:p-3 rounded-xl bg-${color}-100`}>
          <div className={`text-${color}-600`}>{icon}</div>
        </div>
        {trend && trendValue !== undefined && trendValue !== 0 && (
          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
            trend === 'down' ? 'bg-green-100 text-green-700' : 
            trend === 'up' ? 'bg-red-100 text-red-700' : 
            'bg-gray-100 text-gray-700'
          }`}>
            {trend === 'down' ? '↓' : trend === 'up' ? '↑' : '→'}
            {Math.abs(trendValue)}
          </div>
        )}
      </div>
      <div className="text-2xl sm:text-3xl font-bold text-gray-900 mb-1">{value}</div>
      <div className="text-xs sm:text-sm font-medium text-gray-700 mb-1">{title}</div>
      {subtitle && <div className="text-xs text-gray-500">{subtitle}</div>}
    </div>
  );

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="text-center py-2 sm:py-4">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">Today's Dashboard</h2>
        <p className="text-sm sm:text-base text-gray-600">
          {new Date().toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </p>
      </div>

      {/* Key Stats Grid */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4">
        <StatCard
          title="Total Puffs"
          value={todayStats.totalPuffs}
          subtitle={yesterdayStats ? `vs ${yesterdayStats.totalPuffs} yesterday` : 'Today'}
          icon={<Zap size={20} />}
          trend={
            yesterdayStats ? 
            (todayStats.totalPuffs > yesterdayStats.totalPuffs ? 'up' : 
             todayStats.totalPuffs < yesterdayStats.totalPuffs ? 'down' : 'neutral') : 
            'neutral'
          }
          trendValue={yesterdayStats ? Math.abs(todayStats.totalPuffs - yesterdayStats.totalPuffs) : 0}
          color="blue"
        />
        
        <StatCard
          title="Nicotine Intake"
          value={`${todayStats.totalNicotine}mg`}
          subtitle={`~${nicotinePerPuff.toFixed(2)}mg per puff`}
          icon={<Activity size={20} />}
          trend={
            yesterdayStats ? 
            (todayStats.totalNicotine > yesterdayStats.totalNicotine ? 'up' : 
             todayStats.totalNicotine < yesterdayStats.totalNicotine ? 'down' : 'neutral') : 
            'neutral'
          }
          trendValue={yesterdayStats ? Math.abs(Math.round((todayStats.totalNicotine - yesterdayStats.totalNicotine) * 100) / 100) : 0}
          color="red"
        />
        
        <StatCard
          title="Sessions"
          value={todayStats.sessions}
          subtitle="Vaping sessions"
          icon={<Clock size={20} />}
          color="orange"
        />
        
        <StatCard
          title="Avg Interval"
          value={todayStats.averageTimeBetweenPuffs > 0 ? `${todayStats.averageTimeBetweenPuffs}m` : '-'}
          subtitle="Between puffs"
          icon={<Target size={20} />}
          color="green"
        />
      </div>

      {/* 24-Hour Activity Chart */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg border border-gray-100">
        <div className="flex items-center justify-between mb-4 sm:mb-6">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900">24-Hour Activity</h3>
          <div className="text-xs sm:text-sm text-gray-600">
            Peak: {peakHour.hour}:00 ({peakHour.puffs} puffs)
          </div>
        </div>
        
        <div className="flex items-end justify-between gap-0.5 sm:gap-1 h-24 sm:h-32 mb-4">
          {hourlyData.map((hour) => (
            <div key={hour.hour} className="flex-1 flex flex-col items-center">
              <div 
                className={`w-full rounded-t-md transition-all duration-300 hover:opacity-80 cursor-pointer ${getBarColor(hour.puffs)}`}
                style={{ height: `${getBarHeight(hour.puffs)}%` }}
                title={`${hour.hour}:00 - ${hour.puffs} puffs, ${hour.nicotine.toFixed(2)}mg nicotine`}
              />
              <div className="text-xs text-gray-500 mt-1 transform -rotate-45 origin-top hidden sm:block">
                {hour.hour}
              </div>
              {/* Show only every 4th hour on mobile */}
              <div className="text-xs text-gray-500 mt-1 transform -rotate-45 origin-top sm:hidden">
                {hour.hour % 4 === 0 ? hour.hour : ''}
              </div>
            </div>
          ))}
        </div>
        
        <div className="flex items-center justify-between text-xs text-gray-500">
          <span>Midnight</span>
          <span className="hidden sm:inline">6 AM</span>
          <span>Noon</span>
          <span className="hidden sm:inline">6 PM</span>
          <span>11 PM</span>
        </div>
      </div>

      {/* Quick Insights */}
      <div className="bg-gradient-to-r from-teal-50 to-blue-50 rounded-2xl p-4 sm:p-6 border border-teal-100">
        <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4 flex items-center gap-2">
          <TrendingDown size={18} className="text-teal-600" />
          Today's Insights
        </h3>
        
        <div className="space-y-2 sm:space-y-3">
          {todayStats.totalPuffs === 0 ? (
            <div className="flex items-center gap-3 p-3 bg-green-100 rounded-xl">
              <div className="w-2 h-2 bg-green-500 rounded-full flex-shrink-0"></div>
              <span className="text-xs sm:text-sm text-green-800 font-medium">Great job! No puffs recorded today.</span>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-3 p-3 bg-white rounded-xl">
                <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0"></div>
                <span className="text-xs sm:text-sm text-gray-700">
                  Most active hour: <span className="font-semibold">{peakHour.hour}:00</span> with {peakHour.puffs} puffs
                </span>
              </div>
              
              {yesterdayStats && todayStats.totalPuffs < yesterdayStats.totalPuffs && (
                <div className="flex items-center gap-3 p-3 bg-green-100 rounded-xl">
                  <div className="w-2 h-2 bg-green-500 rounded-full flex-shrink-0"></div>
                  <span className="text-xs sm:text-sm text-green-800 font-medium">
                    You've reduced puffs by {yesterdayStats.totalPuffs - todayStats.totalPuffs} compared to yesterday!
                  </span>
                </div>
              )}
              
              <div className="flex items-center gap-3 p-3 bg-white rounded-xl">
                <div className="w-2 h-2 bg-orange-500 rounded-full flex-shrink-0"></div>
                <span className="text-xs sm:text-sm text-gray-700">
                  Average time between puffs: <span className="font-semibold">
                    {todayStats.averageTimeBetweenPuffs > 0 ? `${todayStats.averageTimeBetweenPuffs} minutes` : 'N/A'}
                  </span>
                </span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Weekly Overview Teaser */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg border border-gray-100">
        <div className="flex items-center justify-between mb-3 sm:mb-4">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Calendar size={18} className="text-purple-600" />
            This Week
          </h3>
          <button className="text-xs sm:text-sm text-teal-600 hover:text-teal-700 font-medium touch-manipulation">
            View Details →
          </button>
        </div>
        
        <div className="grid grid-cols-7 gap-1 sm:gap-2">
          {Array.from({ length: 7 }, (_, i) => {
            const date = new Date();
            date.setDate(date.getDate() - (6 - i));
            const dateStr = date.toISOString().split('T')[0];
            const dayStats = getDailyStats(puffRecords, dateStr);
            const isToday = dateStr === today;
            
            return (
              <div key={i} className={`text-center p-1.5 sm:p-2 rounded-lg ${isToday ? 'bg-teal-100' : 'bg-gray-50'}`}>
                <div className="text-xs text-gray-600 mb-1">
                  {date.toLocaleDateString('en-US', { weekday: 'short' }).slice(0, 1)}
                </div>
                <div className={`text-xs sm:text-sm font-semibold ${isToday ? 'text-teal-700' : 'text-gray-900'}`}>
                  {dayStats.totalPuffs}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};