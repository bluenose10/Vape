import React from 'react';

interface TimelineData {
  timeSlot: string;
  hour: number;
  minute: number;
  puffCount: number;
  totalNicotine: number;
}

interface TimelineProps {
  data: TimelineData[];
}

export const Timeline: React.FC<TimelineProps> = ({ data }) => {
  const maxPuffs = Math.max(...data.map(d => d.puffCount), 1);

  const getIntensityColor = (puffCount: number) => {
    if (puffCount === 0) return 'bg-gray-100';
    const intensity = puffCount / maxPuffs;
    if (intensity <= 0.25) return 'bg-green-200';
    if (intensity <= 0.5) return 'bg-green-400';
    if (intensity <= 0.75) return 'bg-green-600';
    return 'bg-green-800';
  };

  const getTextColor = (puffCount: number) => {
    if (puffCount === 0) return 'text-gray-400';
    const intensity = puffCount / maxPuffs;
    return intensity > 0.5 ? 'text-white' : 'text-gray-700';
  };

  const groupedData = data.reduce((acc, item) => {
    if (!acc[item.hour]) {
      acc[item.hour] = [];
    }
    acc[item.hour].push(item);
    return acc;
  }, {} as Record<number, TimelineData[]>);

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg border border-green-100">
      <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Today's Timeline</h3>
      
      <div className="space-y-2 sm:space-y-3 max-h-80 sm:max-h-96 overflow-y-auto">
        {Object.entries(groupedData).map(([hour, slots]) => (
          <div key={hour} className="flex items-center gap-2">
            <div className="w-10 sm:w-12 text-xs sm:text-sm font-medium text-gray-600 flex-shrink-0">
              {hour.padStart(2, '0')}:00
            </div>
            <div className="flex gap-0.5 sm:gap-1 flex-1">
              {slots.map((slot, index) => (
                <div
                  key={index}
                  className={`flex-1 h-6 sm:h-8 rounded-md ${getIntensityColor(slot.puffCount)} 
                             flex items-center justify-center text-xs font-medium 
                             ${getTextColor(slot.puffCount)} cursor-pointer
                             hover:scale-105 transition-transform border border-green-200 touch-manipulation`}
                  title={`${slot.timeSlot}: ${slot.puffCount} puffs${slot.totalNicotine > 0 ? `, ${slot.totalNicotine.toFixed(2)}mg nicotine` : ''}`}
                >
                  {slot.puffCount > 0 && slot.puffCount}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3 sm:mt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs text-gray-500">
        <div className="flex items-center gap-2">
          <span>Intensity:</span>
          <div className="flex gap-1">
            <div className="w-2 h-2 sm:w-3 sm:h-3 bg-gray-100 rounded border border-gray-200"></div>
            <div className="w-2 h-2 sm:w-3 sm:h-3 bg-green-200 rounded border border-green-300"></div>
            <div className="w-2 h-2 sm:w-3 sm:h-3 bg-green-400 rounded border border-green-500"></div>
            <div className="w-2 h-2 sm:w-3 sm:h-3 bg-green-600 rounded border border-green-700"></div>
            <div className="w-2 h-2 sm:w-3 sm:h-3 bg-green-800 rounded border border-green-900"></div>
          </div>
        </div>
        <span>Each block = 15 minutes</span>
      </div>
    </div>
  );
};