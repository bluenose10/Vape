import React, { useState } from 'react';
import { Plus, CheckCircle } from 'lucide-react';

interface PuffButtonProps {
  onPuff: () => void;
  disabled?: boolean;
}

export const PuffButton: React.FC<PuffButtonProps> = ({ onPuff, disabled = false }) => {
  const [isPressed, setIsPressed] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleClick = () => {
    if (disabled) return;
    
    setIsPressed(true);
    setShowSuccess(true);
    
    // Haptic feedback on supported devices
    if ('vibrate' in navigator) {
      navigator.vibrate(50);
    }
    
    onPuff();
    
    setTimeout(() => {
      setIsPressed(false);
    }, 150);
    
    setTimeout(() => {
      setShowSuccess(false);
    }, 1000);
  };

  return (
    <div className="relative flex items-center justify-center">
      <button
        onClick={handleClick}
        disabled={disabled}
        className={`
          w-16 h-16 sm:w-20 sm:h-20 rounded-full shadow-lg transition-all duration-150 ease-out
          flex items-center justify-center text-white font-semibold text-lg
          touch-manipulation
          ${disabled 
            ? 'bg-gray-400 cursor-not-allowed' 
            : 'bg-gradient-to-br from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 active:scale-95'
          }
          ${isPressed ? 'scale-95 shadow-md' : 'shadow-xl hover:shadow-2xl'}
        `}
        style={{
          transform: isPressed ? 'scale(0.95)' : 'scale(1)',
        }}
      >
        {showSuccess ? (
          <CheckCircle size={28} className="text-white animate-pulse" />
        ) : (
          <Plus size={28} className="text-white" />
        )}
      </button>
      
      {/* Ripple effect */}
      {isPressed && (
        <div className="absolute inset-0 rounded-full border-4 border-green-400 animate-ping opacity-20"></div>
      )}
      
      <div className="absolute -bottom-6 sm:-bottom-8 text-center">
        <span className="text-xs sm:text-sm font-medium text-gray-700">Add Puff</span>
      </div>
    </div>
  );
};