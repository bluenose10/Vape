import React, { useState, useEffect } from 'react';
import { X, Target, Calendar, TrendingDown, Clock, Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Goal {
  id: string;
  goal_type: 'daily_puffs' | 'nicotine_reduction' | 'quit_date' | 'session_limit';
  target_value: number | null;
  current_value: number;
  target_date: string | null;
  is_active: boolean;
  achieved_at: string | null;
}

interface GoalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

export const GoalsModal: React.FC<GoalsModalProps> = ({ isOpen, onClose, userId }) => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [showAddGoal, setShowAddGoal] = useState(false);
  const [newGoal, setNewGoal] = useState({
    goal_type: 'daily_puffs' as Goal['goal_type'],
    target_value: '',
    target_date: '',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && userId) {
      fetchGoals();
    }
  }, [isOpen, userId]);

  const fetchGoals = async () => {
    try {
      const { data, error } = await supabase
        .from('user_goals')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setGoals(data || []);
    } catch (error) {
      console.error('Error fetching goals:', error);
    }
  };

  const handleAddGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('user_goals')
        .insert({
          user_id: userId,
          goal_type: newGoal.goal_type,
          target_value: newGoal.target_value ? parseFloat(newGoal.target_value) : null,
          target_date: newGoal.target_date || null,
        });

      if (error) throw error;

      setNewGoal({
        goal_type: 'daily_puffs',
        target_value: '',
        target_date: '',
      });
      setShowAddGoal(false);
      fetchGoals();
    } catch (error) {
      console.error('Error adding goal:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleGoalActive = async (goalId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('user_goals')
        .update({ is_active: !isActive })
        .eq('id', goalId);

      if (error) throw error;
      fetchGoals();
    } catch (error) {
      console.error('Error updating goal:', error);
    }
  };

  const getGoalIcon = (type: Goal['goal_type']) => {
    switch (type) {
      case 'daily_puffs': return <Target size={20} />;
      case 'nicotine_reduction': return <TrendingDown size={20} />;
      case 'quit_date': return <Calendar size={20} />;
      case 'session_limit': return <Clock size={20} />;
    }
  };

  const getGoalTitle = (type: Goal['goal_type']) => {
    switch (type) {
      case 'daily_puffs': return 'Daily Puff Limit';
      case 'nicotine_reduction': return 'Nicotine Reduction';
      case 'quit_date': return 'Quit Date Goal';
      case 'session_limit': return 'Session Limit';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl max-h-screen overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Your Goals</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Goals List */}
        <div className="space-y-4 mb-6">
          {goals.map((goal) => (
            <div
              key={goal.id}
              className={`p-4 rounded-xl border-2 transition-all ${
                goal.is_active
                  ? 'border-teal-200 bg-teal-50'
                  : 'border-gray-200 bg-gray-50 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`p-2 rounded-lg ${goal.is_active ? 'bg-teal-100 text-teal-600' : 'bg-gray-200 text-gray-500'}`}>
                    {getGoalIcon(goal.goal_type)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{getGoalTitle(goal.goal_type)}</h3>
                    <p className="text-sm text-gray-600">
                      Target: {goal.target_value} {goal.target_date && `by ${new Date(goal.target_date).toLocaleDateString()}`}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => toggleGoalActive(goal.id, goal.is_active)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                    goal.is_active
                      ? 'bg-teal-100 text-teal-700 hover:bg-teal-200'
                      : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                  }`}
                >
                  {goal.is_active ? 'Active' : 'Paused'}
                </button>
              </div>
              
              {goal.achieved_at && (
                <div className="text-xs text-green-600 font-medium">
                  ✓ Achieved on {new Date(goal.achieved_at).toLocaleDateString()}
                </div>
              )}
            </div>
          ))}

          {goals.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Target size={48} className="mx-auto mb-4 opacity-50" />
              <p>No goals set yet. Create your first goal to get started!</p>
            </div>
          )}
        </div>

        {/* Add Goal Section */}
        {!showAddGoal ? (
          <button
            onClick={() => setShowAddGoal(true)}
            className="w-full bg-teal-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-teal-600 transition-colors flex items-center justify-center gap-2"
          >
            <Plus size={20} />
            Add New Goal
          </button>
        ) : (
          <form onSubmit={handleAddGoal} className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-gray-900">Add New Goal</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Goal Type
              </label>
              <select
                value={newGoal.goal_type}
                onChange={(e) => setNewGoal({ ...newGoal, goal_type: e.target.value as Goal['goal_type'] })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              >
                <option value="daily_puffs">Daily Puff Limit</option>
                <option value="nicotine_reduction">Nicotine Reduction %</option>
                <option value="session_limit">Session Limit</option>
                <option value="quit_date">Quit Date</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Target Value
              </label>
              <input
                type="number"
                value={newGoal.target_value}
                onChange={(e) => setNewGoal({ ...newGoal, target_value: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                placeholder="Enter target value"
                min="0"
                step="0.1"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Target Date (Optional)
              </label>
              <input
                type="date"
                value={newGoal.target_date}
                onChange={(e) => setNewGoal({ ...newGoal, target_date: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                min={new Date().toISOString().split('T')[0]}
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowAddGoal(false)}
                className="flex-1 bg-gray-200 text-gray-800 py-3 px-4 rounded-xl font-medium hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 bg-teal-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-teal-600 transition-colors disabled:opacity-50"
              >
                {loading ? 'Adding...' : 'Add Goal'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};