import React, { useState } from 'react';
import { 
  ArrowRight, 
  Shield, 
  TrendingDown, 
  Brain, 
  Heart, 
  Smartphone, 
  BarChart3, 
  Target, 
  Bot, 
  CheckCircle,
  Download,
  Zap,
  Wifi,
  Globe
} from 'lucide-react';
import { PWAInstallModal } from './PWAInstallModal';

interface HomePageProps {
  onGetStarted: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onGetStarted }) => {
  const [showPWAModal, setShowPWAModal] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // PWA Install functionality
  React.useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = () => {
    setShowPWAModal(true);
  };

  const handleActualInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        console.log('User accepted the install prompt');
      }
      setDeferredPrompt(null);
    }
    setShowPWAModal(false);
  };

  const benefits = [
    {
      icon: Heart,
      title: "Improved Heart Health",
      description: "Reduce cardiovascular risks and improve circulation within weeks",
      color: "red"
    },
    {
      icon: Brain,
      title: "Better Mental Clarity",
      description: "Experience improved focus and reduced anxiety as nicotine dependency decreases",
      color: "purple"
    },
    {
      icon: Shield,
      title: "Stronger Immune System",
      description: "Your body's natural defenses strengthen as harmful chemicals are eliminated",
      color: "green"
    },
    {
      icon: TrendingDown,
      title: "Reduced Health Risks",
      description: "Lower your risk of respiratory issues and other vaping-related health concerns",
      color: "blue"
    }
  ];

  const features = [
    {
      icon: Smartphone,
      title: "Smart Tracking",
      description: "Log every puff with precise nicotine calculations based on your device and e-liquid",
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      icon: BarChart3,
      title: "Detailed Analytics",
      description: "Visualize your usage patterns with comprehensive daily, weekly, and monthly reports",
      gradient: "from-green-500 to-emerald-500"
    },
    {
      icon: Target,
      title: "Goal Setting",
      description: "Set personalized reduction goals and track your progress with milestone celebrations",
      gradient: "from-orange-500 to-red-500"
    },
    {
      icon: Bot,
      title: "AI Coach",
      description: "Get personalized insights and recommendations from our intelligent AI assistant",
      gradient: "from-purple-500 to-pink-500"
    }
  ];

  const pwaFeatures = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Loads instantly without app store downloads",
      color: "yellow"
    },
    {
      icon: Wifi,
      title: "Works Offline",
      description: "Track your progress even without internet connection",
      color: "blue"
    },
    {
      icon: Smartphone,
      title: "Native App Feel",
      description: "Full-screen experience that feels like a native app",
      color: "purple"
    },
    {
      icon: Globe,
      title: "Cross-Platform",
      description: "Works seamlessly on any device or operating system",
      color: "green"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-teal-50 to-blue-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-green-600/10 to-teal-600/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 sm:pt-16 pb-16 sm:pb-20">
          <div className="text-center">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 leading-tight">
              Take Control of Your
              <span className="block bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent">
                Vaping Journey
              </span>
            </h1>
            <p className="text-lg sm:text-xl lg:text-2xl text-gray-600 mb-6 sm:mb-8 max-w-3xl mx-auto leading-relaxed px-4">
              Track, analyze, and reduce your vaping habits with intelligent monitoring, 
              personalized insights, and AI-powered coaching to achieve your health goals.
            </p>
            
            {/* Hero Image */}
            <div className="mb-8 sm:mb-12 relative px-4">
              <img 
                src="https://images.pexels.com/photos/7148434/pexels-photo-7148434.jpeg?auto=compress&cs=tinysrgb&w=1200" 
                alt="Person holding vape device - quit vaping journey" 
                className="w-full max-w-2xl mx-auto rounded-2xl shadow-2xl object-cover h-64 sm:h-80 lg:h-96"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl max-w-2xl mx-auto"></div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center px-4">
              <button
                onClick={onGetStarted}
                className="w-full sm:w-auto bg-gradient-to-r from-green-600 to-teal-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-2xl font-semibold text-base sm:text-lg hover:from-green-700 hover:to-teal-700 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center gap-2 touch-manipulation"
              >
                Start Your Journey
                <ArrowRight size={20} />
              </button>
              
              {/* Download App Button */}
              <button
                onClick={handleInstallClick}
                className="w-full sm:w-auto bg-white text-green-600 border-2 border-green-600 px-6 sm:px-8 py-3 sm:py-4 rounded-2xl font-semibold text-base sm:text-lg hover:bg-green-50 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center gap-2 touch-manipulation"
              >
                <Download size={20} />
                Download Our App
              </button>
            </div>
            
            <div className="mt-4 flex flex-col sm:flex-row gap-6 justify-center items-center text-gray-600 text-sm sm:text-base">
              <div className="flex items-center gap-2">
                <CheckCircle size={20} className="text-green-600 flex-shrink-0" />
                <span className="font-medium">Free to use • No credit card required</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* PWA Benefits Section */}
      <div className="py-16 sm:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">
              Why Choose Our Progressive Web App?
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Get all the benefits of a native app without the hassle. Our PWA delivers 
              a superior experience that's fast, reliable, and always up-to-date.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-12">
            {pwaFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="text-center">
                  <div className={`p-4 bg-${feature.color}-100 rounded-2xl w-fit mx-auto mb-4`}>
                    <Icon size={32} className={`text-${feature.color}-600`} />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-sm text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>

          <div className="text-center">
            <button
              onClick={handleInstallClick}
              className="bg-gradient-to-r from-green-600 to-teal-600 text-white px-8 py-4 rounded-2xl font-semibold text-lg hover:from-green-700 hover:to-teal-700 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 inline-flex items-center gap-3 touch-manipulation"
            >
              <Download size={24} />
              Install App Now
            </button>
            <p className="text-sm text-gray-500 mt-3">
              No app store required • Installs in seconds • Works on all devices
            </p>
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="py-16 sm:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">
              Transform Your Health
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Discover the incredible benefits that await you on your journey to reduce or quit vaping. 
              Your body begins healing immediately, and the positive changes compound over time.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div key={index} className="bg-white rounded-2xl p-6 sm:p-8 shadow-lg hover:shadow-xl transition-all transform hover:scale-105">
                  <div className={`p-3 sm:p-4 bg-${benefit.color}-100 rounded-2xl w-fit mb-4 sm:mb-6`}>
                    <Icon size={24} className={`text-${benefit.color}-600 sm:w-8 sm:h-8`} />
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">{benefit.title}</h3>
                  <p className="text-sm sm:text-base text-gray-600 leading-relaxed">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 sm:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">
              Powerful Features for Your Success
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Our comprehensive platform provides everything you need to understand, track, 
              and reduce your vaping habits with precision and intelligence.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 items-center">
            <div className="space-y-6 sm:space-y-8 order-2 lg:order-1">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="flex gap-4 sm:gap-6 items-start">
                    <div className={`p-3 sm:p-4 bg-gradient-to-r ${feature.gradient} rounded-2xl flex-shrink-0`}>
                      <Icon size={20} className="text-white sm:w-6 sm:h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                      <p className="text-sm sm:text-base text-gray-600 leading-relaxed">{feature.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="relative order-1 lg:order-2">
              <img 
                src="https://images.pexels.com/photos/7148435/pexels-photo-7148435.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Various vaping devices and e-cigarettes for tracking habits" 
                className="w-full rounded-2xl shadow-2xl object-cover h-64 sm:h-80 lg:h-96"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Integration Highlight - Green background */}
      <div className="py-16 sm:py-20 bg-gradient-to-r from-green-600 to-teal-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="flex items-center gap-3 mb-4 sm:mb-6">
                <div className="p-2 sm:p-3 bg-white/20 rounded-full">
                  <Bot size={24} className="text-white sm:w-8 sm:h-8" />
                </div>
                <span className="text-lg sm:text-xl font-semibold">AI-Powered Insights</span>
              </div>
              
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4 sm:mb-6">
                Your Personal Vaping Coach
              </h2>
              
              <p className="text-lg sm:text-xl mb-6 sm:mb-8 text-green-100 leading-relaxed">
                Our advanced AI analyzes your unique patterns, identifies triggers, and provides 
                personalized recommendations to help you succeed. Get real-time insights, 
                motivation, and strategies tailored specifically to your journey.
              </p>
              
              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-center gap-3">
                  <CheckCircle size={18} className="text-green-300 flex-shrink-0 sm:w-5 sm:h-5" />
                  <span className="text-base sm:text-lg">Personalized reduction strategies</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle size={18} className="text-green-300 flex-shrink-0 sm:w-5 sm:h-5" />
                  <span className="text-base sm:text-lg">Pattern recognition and trigger identification</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle size={18} className="text-green-300 flex-shrink-0 sm:w-5 sm:h-5" />
                  <span className="text-base sm:text-lg">24/7 support and motivation</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle size={18} className="text-green-300 flex-shrink-0 sm:w-5 sm:h-5" />
                  <span className="text-base sm:text-lg">Progress tracking and celebration</span>
                </div>
              </div>
            </div>
            
            <div className="relative order-1 lg:order-2">
              <img 
                src="https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="AI technology and data analysis for personalized vaping insights" 
                className="w-full rounded-2xl shadow-2xl object-cover h-64 sm:h-80 lg:h-96"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-green-900/30 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Journey Scale Section */}
      <div className="py-16 sm:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">
              Track Every Step of Your Journey
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              From your first puff logged to your final milestone achieved, 
              our platform captures and celebrates every moment of your progress.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            <div className="text-center">
              <div className="bg-gradient-to-r from-red-500 to-orange-500 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                <span className="text-lg sm:text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">Track & Understand</h3>
              <p className="text-sm sm:text-base text-gray-600 leading-relaxed">
                Log your usage with precision. Our smart tracking calculates exact nicotine intake 
                and identifies your unique patterns and triggers.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-gradient-to-r from-yellow-500 to-orange-500 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                <span className="text-lg sm:text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">Reduce & Optimize</h3>
              <p className="text-sm sm:text-base text-gray-600 leading-relaxed">
                Set personalized goals and follow AI-recommended strategies. 
                Gradually reduce your intake while maintaining control and motivation.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-gradient-to-r from-green-500 to-teal-500 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                <span className="text-lg sm:text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">Achieve & Celebrate</h3>
              <p className="text-sm sm:text-base text-gray-600 leading-relaxed">
                Reach your milestones and unlock achievements. 
                Celebrate your success and maintain your new, healthier lifestyle.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Final CTA Section */}
      <div className="py-16 sm:py-20 bg-gradient-to-r from-green-600 to-teal-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4 sm:mb-6">
            Ready to Transform Your Life?
          </h2>
          <p className="text-lg sm:text-xl mb-6 sm:mb-8 text-green-100 leading-relaxed">
            Join thousands of users who have successfully reduced or quit vaping with our intelligent platform. 
            Your journey to better health starts with a single click.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-6 sm:mb-8">
            <button
              onClick={onGetStarted}
              className="w-full sm:w-auto bg-white text-green-600 px-8 sm:px-10 py-3 sm:py-4 rounded-2xl font-bold text-lg sm:text-xl hover:bg-gray-100 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 inline-flex items-center justify-center gap-3 touch-manipulation"
            >
              Start Your Free Journey Today
              <ArrowRight size={24} />
            </button>
            
            <button
              onClick={handleInstallClick}
              className="w-full sm:w-auto bg-green-700 text-white px-8 sm:px-10 py-3 sm:py-4 rounded-2xl font-bold text-lg sm:text-xl hover:bg-green-800 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 inline-flex items-center justify-center gap-3 touch-manipulation"
            >
              <Download size={24} />
              Get The App
            </button>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center items-center text-green-100 text-sm sm:text-base">
            <div className="flex items-center gap-2">
              <CheckCircle size={18} className="flex-shrink-0" />
              <span>No subscription required</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle size={18} className="flex-shrink-0" />
              <span>Privacy-focused design</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle size={18} className="flex-shrink-0" />
              <span>Works on all devices</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-900 text-white py-8 sm:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4">Vape Quit Tracker</h3>
          <p className="text-sm sm:text-base text-gray-400 mb-4 sm:mb-6">
            Empowering healthier choices through intelligent tracking and AI-powered insights.
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-2 sm:gap-6 text-xs sm:text-sm text-gray-400">
            <span>© 2024 Vape Quit Tracker</span>
            <span className="hidden sm:inline">•</span>
            <span>Built with ❤️ for your health</span>
          </div>
        </div>
      </div>

      {/* PWA Install Modal */}
      <PWAInstallModal
        isOpen={showPWAModal}
        onClose={() => setShowPWAModal(false)}
        onInstall={handleActualInstall}
      />
    </div>
  );
};