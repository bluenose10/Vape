import React from 'react';
import { TrendingDown, TrendingUp, Clock, Zap } from 'lucide-react';
import { DailyStats } from '../types';

interface StatsPanelProps {
  todayStats: DailyStats;
  yesterdayStats?: DailyStats;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({ todayStats, yesterdayStats }) => {
  const puffDifference = yesterdayStats ? todayStats.totalPuffs - yesterdayStats.totalPuffs : 0;
  const nicotineDifference = yesterdayStats ? todayStats.totalNicotine - yesterdayStats.totalNicotine : 0;

  const StatCard: React.FC<{
    title: string;
    value: string | number;
    subtitle?: string;
    icon: React.ReactNode;
    trend?: 'up' | 'down' | 'neutral';
    trendValue?: number;
  }> = ({ title, value, subtitle, icon, trend, trendValue }) => (
    <div className="bg-white rounded-xl p-3 sm:p-4 shadow-md border border-green-100">
      <div className="flex items-center justify-between mb-2">
        <div className="text-green-600">{icon}</div>
        {trend && trendValue !== undefined && (
          <div className={`flex items-center gap-1 text-xs font-medium ${
            trend === 'down' ? 'text-green-600' : trend === 'up' ? 'text-red-600' : 'text-gray-600'
          }`}>
            {trend === 'down' ? <TrendingDown size={10} /> : trend === 'up' ? <TrendingUp size={10} /> : null}
            {trendValue !== 0 && Math.abs(trendValue)}
          </div>
        )}
      </div>
      <div className="text-xl sm:text-2xl font-bold text-gray-900">{value}</div>
      <div className="text-xs sm:text-sm text-gray-600">{title}</div>
      {subtitle && <div className="text-xs text-gray-500 mt-1">{subtitle}</div>}
    </div>
  );

  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-4 sm:mb-6">
      <StatCard
        title="Today's Puffs"
        value={todayStats.totalPuffs}
        icon={<Zap size={16} />}
        trend={puffDifference > 0 ? 'up' : puffDifference < 0 ? 'down' : 'neutral'}
        trendValue={puffDifference}
        subtitle={yesterdayStats ? `vs ${yesterdayStats.totalPuffs} yesterday` : undefined}
      />
      
      <StatCard
        title="Nicotine"
        value={`${todayStats.totalNicotine}mg`}
        icon={<TrendingDown size={16} />}
        trend={nicotineDifference > 0 ? 'up' : nicotineDifference < 0 ? 'down' : 'neutral'}
        trendValue={Math.round(Math.abs(nicotineDifference) * 100) / 100}
      />
      
      <StatCard
        title="Sessions"
        value={todayStats.sessions}
        subtitle="Vaping sessions today"
        icon={<Clock size={16} />}
      />
      
      <StatCard
        title="Avg. Interval"
        value={todayStats.averageTimeBetweenPuffs > 0 ? `${todayStats.averageTimeBetweenPuffs}m` : '-'}
        subtitle="Between puffs"
        icon={<Clock size={16} />}
      />
    </div>
  );
};