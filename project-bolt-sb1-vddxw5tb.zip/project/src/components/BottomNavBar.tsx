import React from 'react';
import { MessageCircle, BarChart3, Target, Download } from 'lucide-react';

interface BottomNavBarProps {
  onOpenAIChat: () => void;
  onOpenReports: () => void;
  onOpenGoals: () => void;
  showInstallPrompt?: boolean;
  onInstallClick?: () => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  onOpenAIChat,
  onOpenReports,
  onOpenGoals,
  showInstallPrompt = false,
  onInstallClick,
}) => {
  const buttons = [
    {
      id: 'ai-chat',
      onClick: onOpenAIChat,
      icon: MessageCircle,
      label: 'AI Chat',
      color: 'blue',
      hasIndicator: true,
    },
    {
      id: 'reports',
      onClick: onOpenReports,
      icon: BarChart3,
      label: 'Reports',
      color: 'green',
    },
    {
      id: 'goals',
      onClick: onOpenGoals,
      icon: Target,
      label: 'Goals',
      color: 'orange',
    },
  ];

  // Add install button if PWA can be installed
  if (showInstallPrompt && onInstallClick) {
    buttons.push({
      id: 'install',
      onClick: onInstallClick,
      icon: Download,
      label: 'Install App',
      color: 'purple',
    });
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-30">
      <div className="max-w-md mx-auto px-2 sm:px-4 py-2 sm:py-3">
        <div className={`grid gap-1 ${buttons.length === 4 ? 'grid-cols-4' : 'grid-cols-3'}`}>
          {buttons.map((button) => {
            const Icon = button.icon;
            return (
              <button
                key={button.id}
                onClick={button.onClick}
                className={`flex flex-col items-center gap-1 p-2 sm:p-3 rounded-xl hover:bg-${button.color}-50 transition-colors touch-manipulation group`}
              >
                <div className="relative">
                  <Icon 
                    size={20} 
                    className={`text-${button.color}-600 group-hover:text-${button.color}-700`} 
                  />
                  {button.hasIndicator && (
                    <div className={`absolute -top-1 -right-1 w-2.5 h-2.5 bg-gradient-to-r from-${button.color}-500 to-purple-500 rounded-full animate-pulse`}></div>
                  )}
                </div>
                <span className={`text-xs font-medium text-${button.color}-600 group-hover:text-${button.color}-700 text-center leading-tight`}>
                  {button.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};