import React, { useState } from 'react';
import { X, Check, Info } from 'lucide-react';

interface DeviceType {
  id: string;
  name: string;
  description: string;
  characteristics: string[];
  nicotineRange: string;
  puffRange: string;
  batteryLife: string;
  icon: string;
}

const deviceTypes: DeviceType[] = [
  {
    id: 'disposable',
    name: 'Disposable Vapes',
    description: 'Single-use devices that come pre-filled and pre-charged',
    characteristics: [
      'No maintenance required',
      'Fixed nicotine strength',
      'Compact and portable',
      'Most convenient for beginners'
    ],
    nicotineRange: '20-50mg/mL',
    puffRange: '300-5000 puffs',
    batteryLife: 'Until empty',
    icon: '🔋'
  },
  {
    id: 'pod-system',
    name: 'Pod Systems',
    description: 'Compact devices with replaceable or refillable pods',
    characteristics: [
      'Easy to use and maintain',
      'Refillable or replaceable pods',
      'Good flavor production',
      'Mouth-to-lung vaping style'
    ],
    nicotineRange: '3-50mg/mL',
    puffRange: '200-400 puffs per pod',
    batteryLife: '1-2 days',
    icon: '📱'
  },
  {
    id: 'vape-pen',
    name: 'Vape Pens',
    description: 'Pen-shaped devices with refillable tanks',
    characteristics: [
      'Moderate vapor production',
      'Refillable tanks',
      'Adjustable airflow',
      'Good for beginners to intermediate'
    ],
    nicotineRange: '3-18mg/mL',
    puffRange: '150-300 puffs per tank',
    batteryLife: '6-12 hours',
    icon: '🖊️'
  },
  {
    id: 'box-mod',
    name: 'Box Mods',
    description: 'Advanced devices with customizable settings and high power',
    characteristics: [
      'Variable wattage/voltage',
      'Large vapor production',
      'Customizable settings',
      'For experienced users'
    ],
    nicotineRange: '0-12mg/mL',
    puffRange: '100-200 puffs per tank',
    batteryLife: '4-8 hours',
    icon: '📦'
  },
  {
    id: 'aio',
    name: 'All-in-One (AIO)',
    description: 'Integrated devices combining battery and tank in one unit',
    characteristics: [
      'Built-in tank',
      'Simple operation',
      'Moderate customization',
      'Good middle ground option'
    ],
    nicotineRange: '3-25mg/mL',
    puffRange: '200-350 puffs per fill',
    batteryLife: '8-16 hours',
    icon: '🔧'
  },
  {
    id: 'mechanical-mod',
    name: 'Mechanical Mods',
    description: 'Unregulated devices for advanced users only',
    characteristics: [
      'No electronic components',
      'Requires advanced knowledge',
      'High risk if used improperly',
      'Maximum vapor production'
    ],
    nicotineRange: '0-6mg/mL',
    puffRange: '50-150 puffs per build',
    batteryLife: '2-6 hours',
    icon: '⚡'
  }
];

interface DeviceTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (deviceType: DeviceType) => void;
  currentDevice?: string;
}

export const DeviceTypeModal: React.FC<DeviceTypeModalProps> = ({ 
  isOpen, 
  onClose, 
  onSelect,
  currentDevice 
}) => {
  const [selectedDevice, setSelectedDevice] = useState<string>(currentDevice || '');
  const [showDetails, setShowDetails] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSelect = (device: DeviceType) => {
    setSelectedDevice(device.id);
    onSelect(device);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-screen overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Select Your Device Type</h2>
              <p className="text-gray-600 mt-1">Choose the type that best matches your vaping device</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {deviceTypes.map((device) => (
              <div
                key={device.id}
                className={`relative border-2 rounded-2xl p-6 cursor-pointer transition-all hover:shadow-lg ${
                  selectedDevice === device.id
                    ? 'border-teal-500 bg-teal-50 shadow-md'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => handleSelect(device)}
              >
                {selectedDevice === device.id && (
                  <div className="absolute top-4 right-4 bg-teal-500 text-white rounded-full p-1">
                    <Check size={16} />
                  </div>
                )}

                <div className="text-center mb-4">
                  <div className="text-4xl mb-2">{device.icon}</div>
                  <h3 className="text-lg font-semibold text-gray-900">{device.name}</h3>
                </div>

                <p className="text-sm text-gray-600 mb-4 text-center">
                  {device.description}
                </p>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Nicotine:</span>
                    <span className="font-medium">{device.nicotineRange}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Puffs:</span>
                    <span className="font-medium">{device.puffRange}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Battery:</span>
                    <span className="font-medium">{device.batteryLife}</span>
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowDetails(showDetails === device.id ? null : device.id);
                  }}
                  className="w-full text-xs text-teal-600 hover:text-teal-700 font-medium flex items-center justify-center gap-1"
                >
                  <Info size={14} />
                  {showDetails === device.id ? 'Hide Details' : 'View Details'}
                </button>

                {showDetails === device.id && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <h4 className="text-sm font-semibold text-gray-900 mb-2">Key Features:</h4>
                    <ul className="space-y-1">
                      {device.characteristics.map((char, index) => (
                        <li key={index} className="text-xs text-gray-600 flex items-start gap-2">
                          <span className="text-teal-500 mt-1">•</span>
                          <span>{char}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Information Panel */}
          <div className="mt-8 bg-gradient-to-r from-blue-50 to-teal-50 rounded-2xl p-6 border border-blue-100">
            <div className="flex items-start gap-3">
              <Info className="text-blue-600 mt-1" size={20} />
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Why Device Type Matters</h3>
                <p className="text-sm text-gray-700 mb-3">
                  Different device types have varying nicotine delivery methods, puff counts, and usage patterns. 
                  Selecting the correct type helps us provide more accurate tracking and personalized insights.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-gray-600">
                  <div>
                    <strong>Disposables & Pods:</strong> Higher nicotine, fewer puffs per session
                  </div>
                  <div>
                    <strong>Mods & Pens:</strong> Lower nicotine, more vapor per puff
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-6">
            <button
              onClick={onClose}
              className="flex-1 bg-gray-200 text-gray-800 py-3 px-6 rounded-xl font-medium hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onClose}
              disabled={!selectedDevice}
              className="flex-1 bg-teal-500 text-white py-3 px-6 rounded-xl font-medium hover:bg-teal-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Confirm Selection
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};