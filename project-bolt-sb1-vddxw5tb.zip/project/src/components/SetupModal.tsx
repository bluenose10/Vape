import React, { useState } from 'react';
import { X, Save, Smartphone } from 'lucide-react';
import { UserSettings } from '../types';
import { DeviceTypeModal } from './DeviceTypeModal';

interface SetupModalProps {
  settings: UserSettings;
  onSave: (settings: UserSettings) => void;
  onClose: () => void;
}

export const SetupModal: React.FC<SetupModalProps> = ({ settings, onSave, onClose }) => {
  const [formData, setFormData] = useState(settings);
  const [showDeviceTypes, setShowDeviceTypes] = useState(false);
  const [selectedDeviceType, setSelectedDeviceType] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...formData, setupComplete: true });
    onClose();
  };

  const handleDeviceSelect = (device: any) => {
    setSelectedDeviceType(device.name);
    setShowDeviceTypes(false);
    
    // Auto-adjust settings based on device type
    const deviceDefaults = {
      'disposable': { nicotineConcentration: 20, puffsPerML: 150 },
      'pod-system': { nicotineConcentration: 25, puffsPerML: 120 },
      'vape-pen': { nicotineConcentration: 12, puffsPerML: 100 },
      'box-mod': { nicotineConcentration: 6, puffsPerML: 80 },
      'aio': { nicotineConcentration: 12, puffsPerML: 100 },
      'mechanical-mod': { nicotineConcentration: 3, puffsPerML: 60 }
    };

    const defaults = deviceDefaults[device.id as keyof typeof deviceDefaults];
    if (defaults) {
      setFormData(prev => ({
        ...prev,
        nicotineConcentration: defaults.nicotineConcentration,
        puffsPerML: defaults.puffsPerML
      }));
    }
  };

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Setup Your Tracker</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Device Type Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Device Type
              </label>
              <button
                type="button"
                onClick={() => setShowDeviceTypes(true)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all text-left flex items-center justify-between hover:bg-gray-50"
              >
                <div className="flex items-center gap-3">
                  <Smartphone size={20} className="text-gray-400" />
                  <span className={selectedDeviceType ? 'text-gray-900' : 'text-gray-500'}>
                    {selectedDeviceType || 'Select your device type'}
                  </span>
                </div>
                <span className="text-gray-400">→</span>
              </button>
              <p className="text-xs text-gray-500 mt-1">
                This helps us provide more accurate tracking based on your device
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nicotine Concentration (mg/mL)
              </label>
              <input
                type="number"
                value={formData.nicotineConcentration}
                onChange={(e) => setFormData({ ...formData, nicotineConcentration: Number(e.target.value) })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                min="0"
                max="50"
                step="0.1"
                required
              />
              <p className="text-xs text-gray-500 mt-1">Usually found on your e-liquid bottle</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bottle Size (mL)
              </label>
              <input
                type="number"
                value={formData.bottleSize}
                onChange={(e) => setFormData({ ...formData, bottleSize: Number(e.target.value) })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                min="1"
                max="100"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Estimated Puffs per mL
              </label>
              <input
                type="number"
                value={formData.puffsPerML}
                onChange={(e) => setFormData({ ...formData, puffsPerML: Number(e.target.value) })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                min="50"
                max="200"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                {selectedDeviceType ? 'Auto-adjusted based on your device type' : 'Default is 100 puffs per mL'}
              </p>
            </div>

            <button
              type="submit"
              className="w-full bg-teal-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-teal-600 transition-colors flex items-center justify-center gap-2"
            >
              <Save size={20} />
              Save Settings
            </button>
          </form>
        </div>
      </div>

      <DeviceTypeModal
        isOpen={showDeviceTypes}
        onClose={() => setShowDeviceTypes(false)}
        onSelect={handleDeviceSelect}
        currentDevice={selectedDeviceType}
      />
    </>
  );
};