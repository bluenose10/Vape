import React, { useState, useEffect } from 'react';
import { X, Calendar, TrendingDown, BarChart3, Download } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface PuffRecord {
  id: string;
  timestamp: string;
  calculated_nicotine: number;
}

interface DailyReport {
  date: string;
  total_puffs: number;
  total_nicotine: number;
  sessions: number;
  avg_interval: number;
}

interface ReportsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

export const ReportsModal: React.FC<ReportsModalProps> = ({ isOpen, onClose, userId }) => {
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [dailyReports, setDailyReports] = useState<DailyReport[]>([]);
  const [weeklyReports, setWeeklyReports] = useState<any[]>([]);
  const [monthlyReports, setMonthlyReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    if (isOpen && userId) {
      fetchReports();
    }
  }, [isOpen, userId, activeTab, dateRange]);

  const fetchReports = async () => {
    setLoading(true);
    try {
      if (activeTab === 'daily') {
        await fetchDailyReports();
      } else if (activeTab === 'weekly') {
        await fetchWeeklyReports();
      } else {
        await fetchMonthlyReports();
      }
    } catch (error) {
      console.error('Error fetching reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchDailyReports = async () => {
    const { data, error } = await supabase
      .from('puff_records')
      .select('*')
      .eq('user_id', userId)
      .gte('timestamp', dateRange.start + 'T00:00:00.000Z')
      .lte('timestamp', dateRange.end + 'T23:59:59.999Z')
      .order('timestamp', { ascending: false });

    if (error) throw error;

    // Group by date and calculate stats
    const groupedByDate = (data || []).reduce((acc: any, record: PuffRecord) => {
      const date = record.timestamp.split('T')[0];
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(record);
      return acc;
    }, {});

    const reports = Object.entries(groupedByDate).map(([date, records]: [string, any]) => {
      const totalPuffs = records.length;
      const totalNicotine = records.reduce((sum: number, r: PuffRecord) => sum + r.calculated_nicotine, 0);
      
      // Calculate sessions (puffs within 5 minutes)
      let sessions = 0;
      let lastPuffTime: Date | null = null;
      records.forEach((record: PuffRecord) => {
        const puffTime = new Date(record.timestamp);
        if (!lastPuffTime || (puffTime.getTime() - lastPuffTime.getTime()) > 5 * 60 * 1000) {
          sessions++;
        }
        lastPuffTime = puffTime;
      });

      // Calculate average interval
      let avgInterval = 0;
      if (records.length > 1) {
        const times = records.map((r: PuffRecord) => new Date(r.timestamp).getTime()).sort();
        const intervals = [];
        for (let i = 1; i < times.length; i++) {
          intervals.push(times[i] - times[i - 1]);
        }
        avgInterval = intervals.reduce((sum, interval) => sum + interval, 0) / intervals.length / 60000;
      }

      return {
        date,
        total_puffs: totalPuffs,
        total_nicotine: Math.round(totalNicotine * 100) / 100,
        sessions,
        avg_interval: Math.round(avgInterval)
      };
    }).sort((a, b) => b.date.localeCompare(a.date));

    setDailyReports(reports);
  };

  const fetchWeeklyReports = async () => {
    const { data, error } = await supabase
      .from('puff_records')
      .select('*')
      .eq('user_id', userId)
      .gte('timestamp', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString())
      .order('timestamp', { ascending: false });

    if (error) throw error;

    // Group by week
    const weeklyData: any = {};
    (data || []).forEach((record: PuffRecord) => {
      const date = new Date(record.timestamp);
      const weekStart = new Date(date);
      weekStart.setDate(date.getDate() - date.getDay());
      const weekKey = weekStart.toISOString().split('T')[0];
      
      if (!weeklyData[weekKey]) {
        weeklyData[weekKey] = [];
      }
      weeklyData[weekKey].push(record);
    });

    const reports = Object.entries(weeklyData).map(([weekStart, records]: [string, any]) => {
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      
      return {
        week_start: weekStart,
        week_end: weekEnd.toISOString().split('T')[0],
        total_puffs: records.length,
        total_nicotine: Math.round(records.reduce((sum: number, r: PuffRecord) => sum + r.calculated_nicotine, 0) * 100) / 100,
        daily_average: Math.round(records.length / 7 * 100) / 100
      };
    }).sort((a, b) => b.week_start.localeCompare(a.week_start));

    setWeeklyReports(reports);
  };

  const fetchMonthlyReports = async () => {
    const { data, error } = await supabase
      .from('puff_records')
      .select('*')
      .eq('user_id', userId)
      .gte('timestamp', new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString())
      .order('timestamp', { ascending: false });

    if (error) throw error;

    // Group by month
    const monthlyData: any = {};
    (data || []).forEach((record: PuffRecord) => {
      const date = new Date(record.timestamp);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = [];
      }
      monthlyData[monthKey].push(record);
    });

    const reports = Object.entries(monthlyData).map(([month, records]: [string, any]) => {
      const [year, monthNum] = month.split('-');
      const monthName = new Date(parseInt(year), parseInt(monthNum) - 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      const daysInMonth = new Date(parseInt(year), parseInt(monthNum), 0).getDate();
      
      return {
        month,
        month_name: monthName,
        total_puffs: records.length,
        total_nicotine: Math.round(records.reduce((sum: number, r: PuffRecord) => sum + r.calculated_nicotine, 0) * 100) / 100,
        daily_average: Math.round(records.length / daysInMonth * 100) / 100
      };
    }).sort((a, b) => b.month.localeCompare(a.month));

    setMonthlyReports(reports);
  };

  const exportReport = () => {
    let data, filename;
    
    if (activeTab === 'daily') {
      data = dailyReports;
      filename = `daily-report-${dateRange.start}-to-${dateRange.end}.json`;
    } else if (activeTab === 'weekly') {
      data = weeklyReports;
      filename = `weekly-report-${new Date().toISOString().split('T')[0]}.json`;
    } else {
      data = monthlyReports;
      filename = `monthly-report-${new Date().toISOString().split('T')[0]}.json`;
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-3 sm:p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-screen overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 sm:p-6 rounded-t-2xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Usage Reports</h2>
              <p className="text-sm sm:text-base text-gray-600">Detailed analysis of your vaping patterns</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors touch-manipulation"
            >
              <X size={20} />
            </button>
          </div>

          {/* Tab Navigation */}
          <div className="flex bg-gray-100 rounded-xl p-1">
            <button
              onClick={() => setActiveTab('daily')}
              className={`flex-1 py-2 px-3 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center justify-center gap-1 sm:gap-2 touch-manipulation ${
                activeTab === 'daily'
                  ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Calendar size={14} />
              Daily
            </button>
            <button
              onClick={() => setActiveTab('weekly')}
              className={`flex-1 py-2 px-3 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center justify-center gap-1 sm:gap-2 touch-manipulation ${
                activeTab === 'weekly'
                  ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <BarChart3 size={14} />
              Weekly
            </button>
            <button
              onClick={() => setActiveTab('monthly')}
              className={`flex-1 py-2 px-3 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center justify-center gap-1 sm:gap-2 touch-manipulation ${
                activeTab === 'monthly'
                  ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <TrendingDown size={14} />
              Monthly
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-6">
          {/* Date Range Selector for Daily Reports */}
          {activeTab === 'daily' && (
            <div className="mb-4 sm:mb-6 bg-gray-50 rounded-xl p-3 sm:p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Date Range</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={dateRange.start}
                    onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-base"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                  <input
                    type="date"
                    value={dateRange.end}
                    onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-base"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Export Button */}
          <div className="mb-4 sm:mb-6 flex justify-end">
            <button
              onClick={exportReport}
              className="bg-blue-500 text-white px-3 sm:px-4 py-2 rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center gap-2 text-sm sm:text-base touch-manipulation"
            >
              <Download size={14} />
              Export Report
            </button>
          </div>

          {/* Loading State */}
          {loading && (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading reports...</p>
            </div>
          )}

          {/* Daily Reports */}
          {activeTab === 'daily' && !loading && (
            <div className="space-y-3 sm:space-y-4">
              {dailyReports.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calendar size={48} className="mx-auto mb-4 opacity-50" />
                  <p>No data found for the selected date range.</p>
                </div>
              ) : (
                dailyReports.map((report) => (
                  <div key={report.date} className="bg-white border border-gray-200 rounded-xl p-3 sm:p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                        {new Date(report.date).toLocaleDateString('en-US', { 
                          weekday: 'short', 
                          month: 'short', 
                          day: 'numeric' 
                        })}
                      </h3>
                      <span className="text-xs sm:text-sm text-gray-500">{report.date}</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-blue-600">{report.total_puffs}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Total Puffs</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-red-600">{report.total_nicotine}mg</div>
                        <div className="text-xs sm:text-sm text-gray-600">Nicotine</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-orange-600">{report.sessions}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Sessions</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-green-600">{report.avg_interval}m</div>
                        <div className="text-xs sm:text-sm text-gray-600">Avg Interval</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Weekly Reports */}
          {activeTab === 'weekly' && !loading && (
            <div className="space-y-3 sm:space-y-4">
              {weeklyReports.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <BarChart3 size={48} className="mx-auto mb-4 opacity-50" />
                  <p>No weekly data available yet.</p>
                </div>
              ) : (
                weeklyReports.map((report, index) => (
                  <div key={index} className="bg-white border border-gray-200 rounded-xl p-3 sm:p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                        Week of {new Date(report.week_start).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </h3>
                      <span className="text-xs sm:text-sm text-gray-500">
                        {new Date(report.week_start).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {new Date(report.week_end).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-3 sm:gap-4">
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-blue-600">{report.total_puffs}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Total Puffs</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-red-600">{report.total_nicotine}mg</div>
                        <div className="text-xs sm:text-sm text-gray-600">Total Nicotine</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-green-600">{report.daily_average}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Daily Average</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Monthly Reports */}
          {activeTab === 'monthly' && !loading && (
            <div className="space-y-3 sm:space-y-4">
              {monthlyReports.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <TrendingDown size={48} className="mx-auto mb-4 opacity-50" />
                  <p>No monthly data available yet.</p>
                </div>
              ) : (
                monthlyReports.map((report) => (
                  <div key={report.month} className="bg-white border border-gray-200 rounded-xl p-3 sm:p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-gray-900 text-sm sm:text-base">{report.month_name}</h3>
                      <span className="text-xs sm:text-sm text-gray-500">{report.month}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-3 sm:gap-4">
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-blue-600">{report.total_puffs}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Total Puffs</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-red-600">{report.total_nicotine}mg</div>
                        <div className="text-xs sm:text-sm text-gray-600">Total Nicotine</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg sm:text-2xl font-bold text-green-600">{report.daily_average}</div>
                        <div className="text-xs sm:text-sm text-gray-600">Daily Average</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};