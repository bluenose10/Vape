import React from 'react';
import { X, Download, Smartphone, Wifi, Zap, Shield, Share, MoreVertical } from 'lucide-react';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInstall: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ 
  isOpen, 
  onClose, 
  onInstall 
}) => {
  if (!isOpen) return null;

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isAndroid = /Android/.test(navigator.userAgent);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-green-500 to-teal-500 rounded-full">
                <Download size={20} className="text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Install Vape Quit Tracker</h2>
                <p className="text-sm text-gray-600">Get our app for faster access and offline use</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors touch-manipulation"
            >
              <X size={20} className="text-gray-500" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* PWA Benefits */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">Why install our app?</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Zap size={16} className="text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 text-sm">Lightning Fast</p>
                  <p className="text-xs text-gray-600">Loads instantly, no app store needed</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Wifi size={16} className="text-green-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 text-sm">Works Offline</p>
                  <p className="text-xs text-gray-600">Track puffs even without internet</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Smartphone size={16} className="text-purple-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 text-sm">Native App Feel</p>
                  <p className="text-xs text-gray-600">Full screen experience on your device</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 rounded-lg">
                  <Shield size={16} className="text-orange-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 text-sm">No Storage Bloat</p>
                  <p className="text-xs text-gray-600">Tiny footprint, won't slow your phone</p>
                </div>
              </div>
            </div>
          </div>

          {/* Installation Instructions */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">Install this app on your device:</h3>
            
            {isIOS && (
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                    1
                  </div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-gray-900">Tap the</p>
                    <div className="p-1 bg-blue-100 rounded border border-blue-200">
                      <Share size={14} className="text-blue-600" />
                    </div>
                    <p className="text-sm font-medium text-gray-900">Share button</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                    2
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Select "Add to Home Screen"</p>
                    <p className="text-xs text-gray-600">Scroll down in the share menu to find this option</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                    3
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Tap "Add"</p>
                    <p className="text-xs text-gray-600">The app will appear on your home screen</p>
                  </div>
                </div>
              </div>
            )}

            {isAndroid && (
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                    1
                  </div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-gray-900">Tap the</p>
                    <div className="p-1 bg-green-100 rounded border border-green-200">
                      <MoreVertical size={14} className="text-green-600" />
                    </div>
                    <p className="text-sm font-medium text-gray-900">menu button</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                    2
                  </div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-gray-900">Select</p>
                    <div className="p-1 bg-green-100 rounded border border-green-200">
                      <Download size={14} className="text-green-600" />
                    </div>
                    <p className="text-sm font-medium text-gray-900">"Add to Home screen"</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                    3
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Confirm installation</p>
                    <p className="text-xs text-gray-600">The app will be added to your home screen</p>
                  </div>
                </div>
              </div>
            )}

            {!isIOS && !isAndroid && (
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                    1
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Look for the install prompt</p>
                    <p className="text-xs text-gray-600">Your browser may show an install button</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                    2
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Click "Install"</p>
                    <p className="text-xs text-gray-600">Follow your browser's installation process</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 bg-gray-200 text-gray-800 py-3 px-4 rounded-xl font-medium hover:bg-gray-300 transition-colors touch-manipulation"
            >
              Not now
            </button>
            <button
              onClick={onInstall}
              className="flex-1 bg-gradient-to-r from-green-500 to-teal-500 text-white py-3 px-4 rounded-xl font-medium hover:from-green-600 hover:to-teal-600 transition-all touch-manipulation flex items-center justify-center gap-2"
            >
              <Download size={18} />
              Install App
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};