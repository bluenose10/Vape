/*
  # Goals and Achievements System

  1. New Tables
    - `user_goals`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `goal_type` (text: 'daily_puffs', 'nicotine_reduction', 'quit_date')
      - `target_value` (decimal)
      - `current_value` (decimal)
      - `target_date` (date)
      - `is_active` (boolean)
      - `achieved_at` (timestamptz, optional)
      - `created_at` (timestamp)
    
    - `achievements`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `icon` (text)
      - `criteria_type` (text)
      - `criteria_value` (decimal)
      - `is_active` (boolean)
      - `created_at` (timestamp)
    
    - `user_achievements`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `achievement_id` (uuid, references achievements)
      - `unlocked_at` (timestamptz)
      - `progress` (decimal, 0-100)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Create user_goals table
CREATE TABLE IF NOT EXISTS user_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE NOT NULL,
  goal_type text NOT NULL CHECK (goal_type IN ('daily_puffs', 'nicotine_reduction', 'quit_date', 'session_limit')),
  target_value decimal(10,2),
  current_value decimal(10,2) DEFAULT 0,
  target_date date,
  is_active boolean DEFAULT true,
  achieved_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create achievements table (system-wide achievements)
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  icon text DEFAULT 'trophy',
  criteria_type text NOT NULL,
  criteria_value decimal(10,2),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create user_achievements table (user's unlocked achievements)
CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE NOT NULL,
  achievement_id uuid REFERENCES achievements(id) ON DELETE CASCADE NOT NULL,
  unlocked_at timestamptz DEFAULT now(),
  progress decimal(5,2) DEFAULT 100.0,
  UNIQUE(user_id, achievement_id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_user_goals_user_active ON user_goals(user_id, is_active);
CREATE INDEX IF NOT EXISTS idx_user_achievements_user ON user_achievements(user_id);

-- Enable Row Level Security
ALTER TABLE user_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

-- Create policies for user_goals
CREATE POLICY "Users can manage own goals"
  ON user_goals
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create policies for achievements (read-only for users)
CREATE POLICY "Users can read achievements"
  ON achievements
  FOR SELECT
  TO authenticated
  USING (is_active = true);

-- Create policies for user_achievements
CREATE POLICY "Users can read own achievements"
  ON user_achievements
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own achievements"
  ON user_achievements
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Insert default achievements
INSERT INTO achievements (title, description, icon, criteria_type, criteria_value) VALUES
  ('First Step', 'Logged your first puff - awareness is the beginning of change', 'target', 'first_puff', 1),
  ('Week Warrior', 'Tracked puffs for 7 consecutive days', 'calendar', 'consecutive_days', 7),
  ('Half Way There', 'Reduced daily puffs by 50% from your average', 'trending-down', 'reduction_percentage', 50),
  ('Clean Day', 'Went a full day without any puffs', 'check-circle', 'zero_puff_day', 1),
  ('Session Control', 'Had only 1 vaping session in a day', 'shield', 'single_session_day', 1),
  ('Early Bird', 'Completed 30 days of tracking', 'sunrise', 'tracking_days', 30),
  ('Nicotine Warrior', 'Reduced nicotine intake by 75%', 'heart', 'nicotine_reduction', 75),
  ('Consistency King', 'Logged data for 14 consecutive days', 'crown', 'consecutive_days', 14)
ON CONFLICT DO NOTHING;

-- Create trigger for updated_at on user_goals
CREATE TRIGGER update_user_goals_updated_at
  BEFORE UPDATE ON user_goals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();