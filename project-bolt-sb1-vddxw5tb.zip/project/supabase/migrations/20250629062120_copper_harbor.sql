/*
  # Puff Tracking System

  1. New Tables
    - `puff_records`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `timestamp` (timestamptz)
      - `calculated_nicotine` (decimal)
      - `session_id` (uuid, optional for grouping)
      - `created_at` (timestamp)
    
    - `vaping_sessions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references user_profiles)
      - `start_time` (timestamptz)
      - `end_time` (timestamptz, optional)
      - `total_puffs` (integer)
      - `total_nicotine` (decimal)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Create puff_records table
CREATE TABLE IF NOT EXISTS puff_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE NOT NULL,
  timestamp timestamptz DEFAULT now(),
  calculated_nicotine decimal(6,3) NOT NULL,
  session_id uuid,
  created_at timestamptz DEFAULT now()
);

-- Create vaping_sessions table
CREATE TABLE IF NOT EXISTS vaping_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz,
  total_puffs integer DEFAULT 0,
  total_nicotine decimal(8,3) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_puff_records_user_timestamp ON puff_records(user_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_puff_records_session ON puff_records(session_id);
CREATE INDEX IF NOT EXISTS idx_vaping_sessions_user_time ON vaping_sessions(user_id, start_time DESC);

-- Enable Row Level Security
ALTER TABLE puff_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE vaping_sessions ENABLE ROW LEVEL SECURITY;

-- Create policies for puff_records
CREATE POLICY "Users can read own puff records"
  ON puff_records
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own puff records"
  ON puff_records
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own puff records"
  ON puff_records
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own puff records"
  ON puff_records
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for vaping_sessions
CREATE POLICY "Users can read own sessions"
  ON vaping_sessions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own sessions"
  ON vaping_sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own sessions"
  ON vaping_sessions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own sessions"
  ON vaping_sessions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);