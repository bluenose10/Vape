/*
  # Add device type to user settings

  1. Changes
    - Add device_type column to user_settings table
    - Add device_name column to store the specific device name
    - Update existing records with default values

  2. Security
    - No changes to RLS policies needed
*/

-- Add device type columns to user_settings
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_settings' AND column_name = 'device_type'
  ) THEN
    ALTER TABLE user_settings ADD COLUMN device_type text DEFAULT 'pod-system';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_settings' AND column_name = 'device_name'
  ) THEN
    ALTER TABLE user_settings ADD COLUMN device_name text DEFAULT '';
  END IF;
END $$;

-- Add check constraint for device_type
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints
    WHERE constraint_name = 'user_settings_device_type_check'
  ) THEN
    ALTER TABLE user_settings ADD CONSTRAINT user_settings_device_type_check 
    CHECK (device_type IN ('disposable', 'pod-system', 'vape-pen', 'box-mod', 'aio', 'mechanical-mod'));
  END IF;
END $$;