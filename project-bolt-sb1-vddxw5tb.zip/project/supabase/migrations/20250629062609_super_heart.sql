/*
  # Fix user signup trigger

  1. Database Functions
    - Create or replace the handle_new_user function to automatically create user profiles
    - Ensure the function handles the user creation process properly

  2. Triggers
    - Create trigger on auth.users to call handle_new_user function
    - This will automatically create a user_profile record when a user signs up

  3. Security
    - Ensure RLS policies allow the trigger to insert records
    - Add policy for service role to insert user profiles during signup
*/

-- Create or replace the function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, full_name)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data->>'full_name', '')
  );
  
  -- Also create default user settings
  INSERT INTO public.user_settings (user_id)
  VALUES (new.id);
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop the trigger if it exists and recreate it
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Create the trigger on auth.users
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Add a policy to allow the service role to insert user profiles during signup
CREATE POLICY "Allow service role to insert user profiles" ON public.user_profiles
  FOR INSERT
  TO service_role
  WITH CHECK (true);

-- Add a policy to allow the service role to insert user settings during signup
CREATE POLICY "Allow service role to insert user settings" ON public.user_settings
  FOR INSERT
  TO service_role
  WITH CHECK (true);