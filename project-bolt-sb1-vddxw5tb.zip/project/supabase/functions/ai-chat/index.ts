import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface UserData {
  settings: any;
  puffRecords: any[];
  goals: any[];
  achievements: any[];
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { message, userId } = await req.json()

    if (!message || !userId) {
      throw new Error('Missing required parameters')
    }

    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Fetch user data from database
    const userData = await fetchUserData(supabaseClient, userId)
    
    // Generate system prompt with user data
    const systemPrompt = generateSystemPrompt(userData)
    
    // Call OpenAI API
    const openaiResponse = await callOpenAI([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: message }
    ])

    return new Response(
      JSON.stringify({ 
        response: openaiResponse,
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    console.error('Error in AI chat function:', error)
    return new Response(
      JSON.stringify({ 
        error: 'Failed to process chat message',
        details: error.message 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    )
  }
})

async function fetchUserData(supabase: any, userId: string): Promise<UserData> {
  try {
    // Fetch user settings
    const { data: settings } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', userId)
      .single()

    // Fetch recent puff records (last 30 days)
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
    
    const { data: puffRecords } = await supabase
      .from('puff_records')
      .select('*')
      .eq('user_id', userId)
      .gte('timestamp', thirtyDaysAgo.toISOString())
      .order('timestamp', { ascending: false })

    // Fetch user goals
    const { data: goals } = await supabase
      .from('user_goals')
      .select('*')
      .eq('user_id', userId)
      .eq('is_active', true)

    // Fetch user achievements
    const { data: achievements } = await supabase
      .from('user_achievements')
      .select(`
        *,
        achievements (
          title,
          description,
          icon
        )
      `)
      .eq('user_id', userId)

    return {
      settings: settings || {},
      puffRecords: puffRecords || [],
      goals: goals || [],
      achievements: achievements || []
    }
  } catch (error) {
    console.error('Error fetching user data:', error)
    return {
      settings: {},
      puffRecords: [],
      goals: [],
      achievements: []
    }
  }
}

function generateSystemPrompt(userData: UserData): string {
  const { settings, puffRecords, goals, achievements } = userData
  
  // Calculate basic stats
  const totalPuffs = puffRecords.length
  const totalNicotine = puffRecords.reduce((sum, record) => sum + (record.calculated_nicotine || 0), 0)
  
  // Calculate daily averages
  const uniqueDays = new Set(puffRecords.map(record => record.timestamp.split('T')[0]))
  const dailyAverage = uniqueDays.size > 0 ? Math.round(totalPuffs / uniqueDays.size) : 0
  
  // Get today's stats
  const today = new Date().toISOString().split('T')[0]
  const todayPuffs = puffRecords.filter(record => record.timestamp.startsWith(today))
  
  // Calculate trends (last 7 days vs previous 7 days)
  const sevenDaysAgo = new Date()
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)
  const fourteenDaysAgo = new Date()
  fourteenDaysAgo.setDate(fourteenDaysAgo.getDate() - 14)
  
  const lastWeekPuffs = puffRecords.filter(record => 
    new Date(record.timestamp) >= sevenDaysAgo
  ).length
  
  const previousWeekPuffs = puffRecords.filter(record => {
    const date = new Date(record.timestamp)
    return date >= fourteenDaysAgo && date < sevenDaysAgo
  }).length

  return `You are an AI assistant for a vaping cessation app called "Vape Quit Tracker". Your role is to help users understand their vaping patterns, provide encouragement, and offer personalized insights based on their data.

USER DATA SUMMARY:
- Device: ${settings.device_name || 'Unknown'} (${settings.device_type || 'unknown type'})
- Nicotine Concentration: ${settings.nicotine_concentration || 0}mg/mL
- Bottle Size: ${settings.bottle_size || 0}mL
- Puffs per mL: ${settings.puffs_per_ml || 0}
- Setup Complete: ${settings.setup_complete ? 'Yes' : 'No'}

USAGE STATISTICS (Last 30 days):
- Total Puffs: ${totalPuffs}
- Total Nicotine: ${totalNicotine.toFixed(2)}mg
- Daily Average: ${dailyAverage} puffs/day
- Today's Puffs: ${todayPuffs.length}
- Tracking Days: ${uniqueDays.size}

TRENDS:
- Last 7 days: ${lastWeekPuffs} puffs
- Previous 7 days: ${previousWeekPuffs} puffs
- Trend: ${lastWeekPuffs > previousWeekPuffs ? 'Increasing' : lastWeekPuffs < previousWeekPuffs ? 'Decreasing' : 'Stable'}

ACTIVE GOALS:
${goals.length > 0 ? goals.map(goal => `- ${goal.goal_type}: Target ${goal.target_value}, Current ${goal.current_value}`).join('\n') : '- No active goals set'}

ACHIEVEMENTS:
${achievements.length > 0 ? achievements.map(ach => `- ${ach.achievements?.title}: ${ach.achievements?.description}`).join('\n') : '- No achievements unlocked yet'}

GUIDELINES:
1. Be supportive, encouraging, and non-judgmental
2. Provide specific insights based on the user's actual data
3. Suggest actionable steps for reduction when appropriate
4. Celebrate progress and milestones
5. Keep responses concise but informative (2-3 paragraphs max)
6. Use the data to provide personalized recommendations
7. If asked about specific dates or periods, calculate from the puff records
8. Encourage goal setting if no goals are active
9. Be honest about trends but frame them constructively

RESPONSE STYLE:
- Friendly and conversational
- Data-driven but accessible
- Motivational and solution-focused
- Include specific numbers when relevant
- Offer practical next steps

Remember: You're helping someone on their journey to reduce or quit vaping. Every interaction should move them toward their health goals while being realistic and supportive.`
}

async function callOpenAI(messages: ChatMessage[]): Promise<string> {
  const openaiApiKey = Deno.env.get('OPENAI_API_KEY')
  
  if (!openaiApiKey) {
    throw new Error('OpenAI API key not configured')
  }

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${openaiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: messages,
      max_tokens: 500,
      temperature: 0.7,
      presence_penalty: 0.1,
      frequency_penalty: 0.1,
    }),
  })

  if (!response.ok) {
    const error = await response.text()
    throw new Error(`OpenAI API error: ${error}`)
  }

  const data = await response.json()
  return data.choices[0]?.message?.content || 'Sorry, I could not generate a response.'
}